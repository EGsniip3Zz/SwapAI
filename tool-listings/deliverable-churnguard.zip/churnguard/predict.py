"""
ChurnGuard - Prediction Module
Load trained model and make predictions on new data.
"""

import os
import pandas as pd
import numpy as np
import joblib
from dotenv import load_dotenv

load_dotenv()


class ChurnPredictor:
    """Load model and make churn predictions"""
    
    def __init__(self, model_path=None):
        self.model_path = model_path or os.getenv('MODEL_PATH', './models/churn_model.pkl')
        self.model = None
        self.scaler = None
        self.label_encoders = None
        self.load_model()
    
    def load_model(self):
        """Load trained model and preprocessors"""
        if not os.path.exists(self.model_path):
            raise FileNotFoundError(f"Model not found: {self.model_path}")
        
        model_data = joblib.load(self.model_path)
        self.model = model_data['model']
        self.scaler = model_data['scaler']
        self.label_encoders = model_data.get('label_encoders', {})
    
    def engineer_features(self, df):
        """Apply feature engineering"""
        df = df.copy()
        
        df['tenure_squared'] = df['tenure_months'] ** 2
        df['tenure_log'] = np.log1p(df['tenure_months'])
        df['monthly_to_total_ratio'] = df['monthly_charges'] / (df['total_charges'] + 1)
        df['avg_monthly'] = df['total_charges'] / (df['tenure_months'] + 1)
        df['support_per_month'] = df['support_tickets'] / (df['tenure_months'] + 1)
        df['high_support_flag'] = (df['support_tickets'] > 3).astype(int)
        
        median_charges = df['monthly_charges'].median()
        df['high_charges_flag'] = (df['monthly_charges'] > median_charges * 1.25).astype(int)
        
        return df
    
    def encode_categorical(self, df):
        """Encode categorical features"""
        df = df.copy()
        
        for col in ['contract_type']:
            if col in df.columns and col in self.label_encoders:
                df[col] = self.label_encoders[col].transform(df[col].astype(str))
        
        return df
    
    def get_risk_level(self, probability):
        """Determine risk level from probability"""
        if probability < 0.30:
            return 'low'
        elif probability < 0.60:
            return 'medium'
        elif probability < 0.80:
            return 'high'
        else:
            return 'critical'
    
    def get_recommended_action(self, risk_level):
        """Get action recommendation based on risk"""
        actions = {
            'low': 'Standard engagement',
            'medium': 'Upgrade opportunity',
            'high': 'Proactive retention',
            'critical': 'Executive outreach'
        }
        return actions.get(risk_level, 'Monitor')
    
    def predict_single(self, customer_data):
        """Predict churn for single customer"""
        df = pd.DataFrame([customer_data])
        return self.predict_batch(df)[0]
    
    def predict_batch(self, df):
        """Predict churn for batch of customers"""
        df = self.engineer_features(df)
        df = self.encode_categorical(df)
        
        feature_cols = [
            'tenure_months', 'monthly_charges', 'total_charges',
            'contract_type', 'support_tickets', 'tenure_squared',
            'tenure_log', 'monthly_to_total_ratio', 'avg_monthly',
            'support_per_month', 'high_support_flag', 'high_charges_flag'
        ]
        
        X = df[feature_cols]
        X_scaled = self.scaler.transform(X)
        
        probabilities = self.model.predict_proba(X_scaled)[:, 1]
        
        predictions = []
        for idx, prob in enumerate(probabilities):
            customer_id = df.iloc[idx].get('customer_id', f'CUST_{idx}')
            risk_level = self.get_risk_level(prob)
            
            predictions.append({
                'customer_id': str(customer_id),
                'churn_probability': float(prob),
                'risk_level': risk_level,
                'recommended_action': self.get_recommended_action(risk_level)
            })
        
        return predictions


if __name__ == '__main__':
    # Example usage
    predictor = ChurnPredictor()
    
    # Single prediction
    customer = {
        'customer_id': 'CUST123',
        'tenure_months': 12,
        'monthly_charges': 65.50,
        'total_charges': 786.00,
        'contract_type': 'month-to-month',
        'support_tickets': 2
    }
    
    result = predictor.predict_single(customer)
    print(f"Customer {result['customer_id']}: {result['churn_probability']:.1%} risk ({result['risk_level']})")
