# ChurnGuard - AI Churn Prediction Engine

**Enterprise-grade machine learning solution for predicting customer churn and retention risk with 92%+ accuracy.**

## Overview

ChurnGuard uses advanced Random Forest algorithms to identify at-risk customers before they leave. Integrated with your CRM, it provides actionable predictions to improve retention rates and maximize customer lifetime value.

**Pricing:** $1,497 one-time license
**Licensing Model:** Commercial use included, unlimited predictions
**ROI:** Typical payback in 2-4 months

## Requirements

- Python 3.8+
- scikit-learn 1.0+
- pandas 1.3+
- numpy 1.20+
- 4GB RAM minimum
- Historical customer data (minimum 500 records recommended)

## Installation & Setup

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Environment Configuration

```bash
cp .env.example .env
```

Update environment variables:

```
MODEL_PATH=./models/churn_model.pkl
API_KEY=your_secret_api_key
LOG_LEVEL=INFO
```

### 3. Train the Model

Prepare your data in CSV format with required columns:
- customer_id
- tenure_months
- monthly_charges
- total_charges
- contract_type
- support_tickets
- churned (target: 0 or 1)

```bash
python train_model.py --input data/customers.csv --output models/churn_model.pkl
```

Example output:
```
Training model...
Cross-validation scores: [0.885, 0.891, 0.887]
Mean CV Score: 0.888 (+/- 0.002)
Model saved to: models/churn_model.pkl
```

### 4. Start the API Server

```bash
python api/server.py
```

Server runs on `http://localhost:8000`

## Data Format

### Input CSV Columns

| Column | Type | Description |
|--------|------|-------------|
| customer_id | string | Unique customer identifier |
| tenure_months | int | Months as customer |
| monthly_charges | float | Monthly bill amount |
| total_charges | float | Lifetime charges |
| contract_type | string | 'month-to-month', 'one-year', 'two-year' |
| support_tickets | int | Support tickets submitted |
| churned | int | 0 = stayed, 1 = left |

### Sample Data

See `sample_data/customers.csv` for example format.

## API Endpoints

### Single Customer Prediction
```
POST /predict
Content-Type: application/json

{
    "customer_id": "CUST123",
    "tenure_months": 12,
    "monthly_charges": 65.50,
    "total_charges": 786.00,
    "contract_type": "month-to-month",
    "support_tickets": 2
}

Response:
{
    "customer_id": "CUST123",
    "churn_probability": 0.73,
    "risk_level": "high",
    "recommended_action": "Outreach with retention offer"
}
```

### Batch Prediction
```
POST /batch-predict
Content-Type: application/json

{
    "customers": [
        { customer data objects },
        ...
    ]
}

Response:
{
    "predictions": [ { prediction objects } ],
    "total": 100,
    "high_risk": 23,
    "processing_time_ms": 145
}
```

### Model Retraining
```
POST /retrain
Content-Type: application/json

{
    "api_key": "your_api_key",
    "data_file": "path/to/new_training_data.csv"
}

Response:
{
    "status": "success",
    "model_version": "2.1",
    "cv_score": 0.892,
    "training_time_seconds": 23
}
```

## Feature Engineering

The model automatically engineers these features:

- **Tenure Squared**: Non-linear tenure relationship
- **Monthly to Total Ratio**: Payment consistency indicator
- **Support Intensity**: Support tickets per month
- **Contract Risk**: Encoded contract type (month-to-month = high risk)
- **High Charge Flag**: Customers paying > 75th percentile

## Model Performance

Trained on 10,000+ customer records:
- Accuracy: 92.3%
- Precision: 88.7%
- Recall: 85.4%
- F1 Score: 0.870
- ROC-AUC: 0.936

## Predictions Interpretation

### Churn Probability Ranges

| Probability | Risk Level | Recommended Action |
|-------------|------------|-------------------|
| 0.0 - 0.30 | Low | Standard engagement |
| 0.30 - 0.60 | Medium | Upgrade opportunity |
| 0.60 - 0.80 | High | Proactive retention |
| 0.80 - 1.0 | Critical | Executive outreach |

## Integration Examples

### Python Client

```python
import requests
import json

API_URL = 'http://localhost:8000'

def predict_churn(customer_data):
    response = requests.post(
        f'{API_URL}/predict',
        json=customer_data,
        headers={'Authorization': 'Bearer YOUR_API_KEY'}
    )
    return response.json()

# Single prediction
customer = {
    'customer_id': 'CUST456',
    'tenure_months': 6,
    'monthly_charges': 85.00,
    'total_charges': 510.00,
    'contract_type': 'month-to-month',
    'support_tickets': 5
}

result = predict_churn(customer)
print(f"Churn Risk: {result['churn_probability']:.1%}")
```

### Batch Processing

```python
customers_df = pd.read_csv('customer_list.csv')

# Convert to dict records
customers = customers_df.to_dict('records')

# Get predictions
response = requests.post(
    f'{API_URL}/batch-predict',
    json={'customers': customers}
)

predictions = response.json()['predictions']
```

## Deployment

### Production with Gunicorn

```bash
gunicorn --workers 4 --bind 0.0.0.0:8000 api.server:app
```

### Docker Deployment

```dockerfile
FROM python:3.9
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "api/server.py"]
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Invalid API key" | Check API_KEY in .env file |
| "Model not found" | Run train_model.py first |
| "Low CV scores" | Check data quality, add more training records |
| "Predictions all zeros" | Verify feature engineering pipeline |

## License & Support

License: Commercial (one-time $1,497)
Updates: Included for 2 years
Support: Email + priority response
Training: 2 hours of custom consultation included

For support: support@churnguard.com
Documentation: https://docs.churnguard.com

## Version History

- v2.0.0 - Multi-model ensemble (Feb 2025)
- v1.5.0 - REST API enhancements
- v1.0.0 - Initial release
