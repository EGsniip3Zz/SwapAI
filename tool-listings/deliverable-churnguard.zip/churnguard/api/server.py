"""
ChurnGuard - FastAPI Server
REST API for churn prediction with authentication and batch processing.
"""

import os
import time
import logging
from datetime import datetime
from typing import List, Dict, Any

from fastapi import FastAPI, HTTPException, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import pandas as pd
from dotenv import load_dotenv

from predict import ChurnPredictor

load_dotenv()

logging.basicConfig(level=os.getenv('LOG_LEVEL', 'INFO'))
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="ChurnGuard API",
    description="AI-powered churn prediction service",
    version="2.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize predictor
try:
    predictor = ChurnPredictor()
    logger.info("ChurnGuard model loaded successfully")
except Exception as e:
    logger.error(f"Failed to load model: {e}")
    predictor = None

# Configuration
API_KEY = os.getenv('API_KEY', 'default-api-key')


class CustomerData(BaseModel):
    """Single customer data"""
    customer_id: str
    tenure_months: int = Field(ge=0, le=100)
    monthly_charges: float = Field(ge=0)
    total_charges: float = Field(ge=0)
    contract_type: str = Field(pattern="^(month-to-month|one-year|two-year)$")
    support_tickets: int = Field(ge=0, le=50)


class PredictionResult(BaseModel):
    """Prediction result"""
    customer_id: str
    churn_probability: float
    risk_level: str
    recommended_action: str


class BatchPredictionRequest(BaseModel):
    """Batch prediction request"""
    customers: List[Dict[str, Any]]


class RetrainRequest(BaseModel):
    """Model retraining request"""
    api_key: str
    data_file: str


def verify_api_key(authorization: str = Header(None)):
    """Verify API key from Authorization header"""
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing API key")
    
    try:
        scheme, credentials = authorization.split()
        if scheme.lower() != 'bearer':
            raise HTTPException(status_code=401, detail="Invalid authorization scheme")
        
        if credentials != API_KEY:
            raise HTTPException(status_code=401, detail="Invalid API key")
    except ValueError:
        raise HTTPException(status_code=401, detail="Invalid authorization format")


@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "model_loaded": predictor is not None
    }


@app.post("/predict", response_model=PredictionResult)
def predict(customer: CustomerData, authorization: str = Header(None)):
    """
    Predict churn for a single customer
    
    Example:
        POST /predict
        Authorization: Bearer YOUR_API_KEY
        
        {
            "customer_id": "CUST123",
            "tenure_months": 12,
            "monthly_charges": 65.50,
            "total_charges": 786.00,
            "contract_type": "month-to-month",
            "support_tickets": 2
        }
    """
    verify_api_key(authorization)
    
    if predictor is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    try:
        result = predictor.predict_single(customer.dict())
        return result
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/batch-predict")
def batch_predict(request: BatchPredictionRequest, authorization: str = Header(None)):
    """
    Predict churn for multiple customers
    
    Returns predictions and summary statistics
    """
    verify_api_key(authorization)
    
    if predictor is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    if not request.customers:
        raise HTTPException(status_code=400, detail="No customers provided")
    
    if len(request.customers) > 10000:
        raise HTTPException(status_code=400, detail="Maximum 10,000 customers per request")
    
    start_time = time.time()
    
    try:
        df = pd.DataFrame(request.customers)
        predictions = predictor.predict_batch(df)
        
        # Calculate statistics
        risk_counts = {}
        for pred in predictions:
            risk = pred['risk_level']
            risk_counts[risk] = risk_counts.get(risk, 0) + 1
        
        processing_time = (time.time() - start_time) * 1000
        
        return {
            "predictions": predictions,
            "total": len(predictions),
            "high_risk": risk_counts.get('high', 0) + risk_counts.get('critical', 0),
            "processing_time_ms": processing_time,
            "risk_distribution": risk_counts
        }
    except Exception as e:
        logger.error(f"Batch prediction error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/retrain")
def retrain(request: RetrainRequest):
    """
    Retrain model with new data (requires API key)
    
    Example:
        POST /retrain
        {
            "api_key": "your_api_key",
            "data_file": "path/to/training_data.csv"
        }
    """
    if request.api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")
    
    if not os.path.exists(request.data_file):
        raise HTTPException(status_code=400, detail="Data file not found")
    
    try:
        from train_model import ChurnModelTrainer
        
        logger.info(f"Starting retraining with {request.data_file}")
        
        start_time = time.time()
        
        df = pd.read_csv(request.data_file)
        trainer = ChurnModelTrainer()
        metrics = trainer.train(df, cv_folds=5)
        model_path = trainer.save()
        
        # Reload predictor with new model
        global predictor
        predictor = ChurnPredictor(model_path)
        
        training_time = time.time() - start_time
        
        return {
            "status": "success",
            "model_version": "2.0.0",
            "cv_score": metrics['cv_mean'],
            "training_time_seconds": training_time,
            "model_path": model_path,
            "samples_trained": len(df)
        }
    except Exception as e:
        logger.error(f"Retraining error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/analytics")
def get_analytics(data: BatchPredictionRequest, authorization: str = Header(None)):
    """Get analytics on predictions"""
    verify_api_key(authorization)
    
    if predictor is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    try:
        df = pd.DataFrame(data.customers)
        predictions = predictor.predict_batch(df)
        
        probs = [p['churn_probability'] for p in predictions]
        
        return {
            "total_customers": len(predictions),
            "avg_churn_risk": sum(probs) / len(probs),
            "high_risk_count": sum(1 for p in predictions if p['risk_level'] in ['high', 'critical']),
            "high_risk_percentage": 100 * sum(1 for p in predictions if p['risk_level'] in ['high', 'critical']) / len(predictions),
            "min_risk": min(probs),
            "max_risk": max(probs),
            "median_risk": sorted(probs)[len(probs)//2]
        }
    except Exception as e:
        logger.error(f"Analytics error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == '__main__':
    import uvicorn
    port = int(os.getenv('PORT', 8000))
    uvicorn.run(app, host='0.0.0.0', port=port)
