"""
ChurnGuard - Model Training Script
Trains a Random Forest churn prediction model with cross-validation.
"""

import os
import sys
import argparse
import json
import logging
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
import joblib
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=os.getenv('LOG_LEVEL', 'INFO'),
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ChurnModelTrainer:
    """Train and validate churn prediction models"""
    
    def __init__(self, output_path=None):
        self.output_path = output_path or os.getenv('MODEL_PATH', './models/churn_model.pkl')
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.model = None
        Path(self.output_path).parent.mkdir(parents=True, exist_ok=True)
    
    def engineer_features(self, df):
        """Create derived features from raw data"""
        df = df.copy()
        
        # Tenure-based features
        df['tenure_squared'] = df['tenure_months'] ** 2
        df['tenure_log'] = np.log1p(df['tenure_months'])
        
        # Payment-based features
        df['monthly_to_total_ratio'] = df['monthly_charges'] / (df['total_charges'] + 1)
        df['avg_monthly'] = df['total_charges'] / (df['tenure_months'] + 1)
        
        # Support intensity
        df['support_per_month'] = df['support_tickets'] / (df['tenure_months'] + 1)
        df['high_support_flag'] = (df['support_tickets'] > 3).astype(int)
        
        # Charge-based features
        median_charges = df['monthly_charges'].median()
        df['high_charges_flag'] = (df['monthly_charges'] > median_charges * 1.25).astype(int)
        
        return df
    
    def encode_categorical(self, df, fit=True):
        """Encode categorical variables"""
        df = df.copy()
        
        categorical_cols = ['contract_type']
        
        for col in categorical_cols:
            if col not in df.columns:
                continue
            
            if fit:
                self.label_encoders[col] = LabelEncoder()
                df[col] = self.label_encoders[col].fit_transform(df[col].astype(str))
            else:
                if col in self.label_encoders:
                    df[col] = self.label_encoders[col].transform(df[col].astype(str))
        
        return df
    
    def prepare_data(self, df, fit_scaler=True):
        """Prepare data for training"""
        df = self.engineer_features(df)
        df = self.encode_categorical(df, fit=fit_scaler)
        
        # Select features
        feature_cols = [
            'tenure_months', 'monthly_charges', 'total_charges', 
            'contract_type', 'support_tickets', 'tenure_squared',
            'tenure_log', 'monthly_to_total_ratio', 'avg_monthly',
            'support_per_month', 'high_support_flag', 'high_charges_flag'
        ]
        
        X = df[feature_cols]
        y = df['churned']
        
        if fit_scaler:
            X_scaled = self.scaler.fit_transform(X)
        else:
            X_scaled = self.scaler.transform(X)
        
        return X_scaled, y, feature_cols
    
    def train(self, df, cv_folds=5):
        """Train model with cross-validation"""
        logger.info("Preparing training data...")
        X, y, feature_cols = self.prepare_data(df, fit_scaler=True)
        
        logger.info(f"Training data shape: {X.shape}")
        logger.info(f"Positive class: {y.sum()} ({100*y.mean():.1f}%)")
        
        # Initialize model
        self.model = RandomForestClassifier(
            n_estimators=200,
            max_depth=20,
            min_samples_split=10,
            min_samples_leaf=5,
            random_state=42,
            n_jobs=-1,
            class_weight='balanced'
        )
        
        logger.info(f"Starting {cv_folds}-fold cross-validation...")
        
        # Cross-validation
        cv_scores = cross_val_score(
            self.model, X, y, cv=cv_folds, scoring='roc_auc', n_jobs=-1
        )
        
        logger.info(f"Cross-validation scores: {[f'{s:.3f}' for s in cv_scores]}")
        logger.info(f"Mean CV Score: {cv_scores.mean():.3f} (+/- {cv_scores.std():.3f})")
        
        # Train final model on full data
        logger.info("Training final model on full dataset...")
        self.model.fit(X, y)
        
        # Feature importance
        importances = self.model.feature_importances_
        feature_importance = dict(zip(feature_cols, importances))
        top_features = sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)[:5]
        
        logger.info("Top 5 important features:")
        for feat, imp in top_features:
            logger.info(f"  {feat}: {imp:.3f}")
        
        # Test set evaluation (for reference)
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        self.model.fit(X_train, y_train)
        
        y_pred = self.model.predict(X_test)
        y_pred_proba = self.model.predict_proba(X_test)[:, 1]
        
        test_auc = roc_auc_score(y_test, y_pred_proba)
        logger.info(f"Test Set ROC-AUC: {test_auc:.3f}")
        
        return {
            'cv_scores': cv_scores.tolist(),
            'cv_mean': float(cv_scores.mean()),
            'cv_std': float(cv_scores.std()),
            'test_auc': float(test_auc),
            'feature_importance': feature_importance
        }
    
    def save(self):
        """Save model and preprocessing objects"""
        if self.model is None:
            raise ValueError("No model trained yet")
        
        model_data = {
            'model': self.model,
            'scaler': self.scaler,
            'label_encoders': self.label_encoders,
            'version': '2.0.0'
        }
        
        joblib.dump(model_data, self.output_path)
        logger.info(f"Model saved to: {self.output_path}")
        
        return self.output_path


def main():
    parser = argparse.ArgumentParser(description='Train ChurnGuard churn prediction model')
    parser.add_argument('--input', '-i', type=str, required=True, help='Input CSV file path')
    parser.add_argument('--output', '-o', type=str, help='Output model path')
    parser.add_argument('--cv-folds', type=int, default=5, help='Cross-validation folds')
    
    args = parser.parse_args()
    
    if not os.path.exists(args.input):
        logger.error(f"Input file not found: {args.input}")
        sys.exit(1)
    
    logger.info(f"Loading data from: {args.input}")
    df = pd.read_csv(args.input)
    
    trainer = ChurnModelTrainer(output_path=args.output)
    
    logger.info("Training model...")
    metrics = trainer.train(df, cv_folds=args.cv_folds)
    
    model_path = trainer.save()
    
    logger.info("Training complete!")
    logger.info(json.dumps(metrics, indent=2))


if __name__ == '__main__':
    main()
