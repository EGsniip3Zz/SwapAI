"""FunnelForge analytics module."""
