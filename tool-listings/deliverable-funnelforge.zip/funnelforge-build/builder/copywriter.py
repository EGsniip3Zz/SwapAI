"""
FunnelForge AI Copywriter

Generates headlines, CTAs, email sequences, and ad copy using OpenAI.
"""

import openai
import os
from typing import Dict, Optional, List
from dotenv import load_dotenv


class CopyWriter:
    """Generates marketing copy using AI."""
    
    def __init__(self):
        """Initialize copywriter."""
        load_dotenv()
        self.api_key = os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("OPENAI_API_KEY not found")
        openai.api_key = self.api_key
    
    def generate_headline(
        self,
        product: str,
        audience: str,
        benefit: Optional[str] = None,
        style: str = "benefit-driven"
    ) -> List[str]:
        """
        Generate marketing headlines.
        
        Args:
            product: Product/offer name
            audience: Target audience
            benefit: Key benefit
            style: Headline style (benefit-driven, curiosity, urgency, etc.)
            
        Returns:
            List of generated headlines
        """
        benefit_text = f"Key benefit: {benefit}" if benefit else ""
        
        prompt = f"""Generate 5 compelling marketing headlines for:
Product: {product}
Target Audience: {audience}
{benefit_text}
Style: {style}

Requirements:
- Headlines should be attention-grabbing
- Include benefit or curiosity element
- Keep under 10 words
- Use power words

Return only the headlines, one per line."""
        
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.8,
                max_tokens=300
            )
            
            headlines = response.choices[0].message.content.strip().split('\n')
            return [h.strip() for h in headlines if h.strip()]
        
        except Exception as e:
            print(f"Headline generation failed: {e}")
            return [f"Discover {product} Today"]
    
    def generate_cta(
        self,
        action: str,
        urgency: Optional[str] = None,
        count: int = 3
    ) -> List[str]:
        """
        Generate call-to-action text.
        
        Args:
            action: Desired action (buy, sign up, register, etc.)
            urgency: Urgency element (limited time, limited spots, etc.)
            count: Number of variations
            
        Returns:
            List of CTA text variations
        """
        urgency_text = f"Include urgency: {urgency}" if urgency else ""
        
        prompt = f"""Generate {count} compelling call-to-action phrases for:
Action: {action}
{urgency_text}

Requirements:
- Action-oriented
- Create sense of urgency or benefit
- Keep under 5 words
- Use first person or direct address

Return only the CTAs, one per line."""
        
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=200
            )
            
            ctas = response.choices[0].message.content.strip().split('\n')
            return [c.strip() for c in ctas if c.strip()]
        
        except Exception as e:
            print(f"CTA generation failed: {e}")
            return [f"{action.capitalize()} Now"]
    
    def generate_email_body(
        self,
        subject: str,
        sequence_number: int = 1,
        total_emails: int = 5
    ) -> str:
        """
        Generate email body for sequence.
        
        Args:
            subject: Email sequence subject/topic
            sequence_number: Email number in sequence
            total_emails: Total emails in sequence
            
        Returns:
            Generated email body
        """
        prompt = f"""Write email {sequence_number} of {total_emails} in a sales sequence.
Subject: {subject}

Requirements:
- Email {sequence_number} should {'introduce the problem/opportunity' if sequence_number == 1 else 'build on previous emails' if sequence_number < total_emails else 'create urgency for action'}
- Personable, conversational tone
- Include relevant CTA
- Keep around 200 words
- Start with engaging hook

Generate only the email body, no subject line."""
        
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=400
            )
            
            return response.choices[0].message.content.strip()
        
        except Exception as e:
            print(f"Email generation failed: {e}")
            return f"Email {sequence_number} of {total_emails} regarding {subject}"
    
    def generate_ad_copy(
        self,
        product: str,
        platform: str = "facebook",
        character_limit: Optional[int] = None
    ) -> Dict[str, str]:
        """
        Generate ad copy for multiple platforms.
        
        Args:
            product: Product/offer name
            platform: Ad platform (facebook, google, linkedin, twitter)
            character_limit: Character limit if specified
            
        Returns:
            Dictionary with headline and body
        """
        limits = {
            "facebook": 125,
            "google": 90,
            "linkedin": 150,
            "twitter": 280
        }
        
        char_limit = character_limit or limits.get(platform, 125)
        
        prompt = f"""Generate ad copy for {platform} with {char_limit} character limit.
Product: {product}

Include:
- Attention-grabbing headline
- Benefit-focused copy
- Clear CTA

Format:
Headline: [headline]
Body: [body copy]"""
        
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=300
            )
            
            text = response.choices[0].message.content.strip()
            lines = text.split('\n')
            
            result = {}
            for line in lines:
                if line.startswith("Headline:"):
                    result["headline"] = line.replace("Headline:", "").strip()
                elif line.startswith("Body:"):
                    result["body"] = line.replace("Body:", "").strip()
            
            return result
        
        except Exception as e:
            print(f"Ad copy generation failed: {e}")
            return {"headline": product, "body": "Learn more"}
