"""
FunnelForge Funnel Builder

Creates landing pages, opt-in forms, and checkout flows using templates and AI.
"""

import json
from typing import Dict, List, Any, Optional
from datetime import datetime
from enum import Enum


class FunnelType(Enum):
    """Available funnel types."""
    WEBINAR = "webinar"
    PRODUCT_LAUNCH = "product_launch"
    ECOMMERCE = "ecommerce"
    LEAD_GEN = "lead_gen"
    MEMBERSHIP = "membership"
    VSL = "vsl"


class FunnelBuilder:
    """Builds sales funnels with pages and flows."""
    
    def __init__(self):
        """Initialize funnel builder."""
        self.funnels = {}
    
    def create_funnel(
        self,
        name: str,
        funnel_type: FunnelType,
        product_name: str,
        target_audience: str,
        description: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a new funnel.
        
        Args:
            name: Funnel name
            funnel_type: Type of funnel
            product_name: Product/offer name
            target_audience: Target audience description
            description: Funnel description
            
        Returns:
            Created funnel configuration
        """
        funnel_id = f"funnel_{int(datetime.now().timestamp())}"
        
        funnel = {
            "id": funnel_id,
            "name": name,
            "type": funnel_type.value,
            "product_name": product_name,
            "target_audience": target_audience,
            "description": description,
            "pages": [],
            "forms": [],
            "email_sequences": [],
            "created_at": datetime.now().isoformat(),
            "analytics": {
                "visits": 0,
                "conversions": 0,
                "revenue": 0
            }
        }
        
        self.funnels[funnel_id] = funnel
        
        # Create default pages based on funnel type
        self._create_default_pages(funnel_id, funnel_type)
        
        return funnel
    
    def _create_default_pages(self, funnel_id: str, funnel_type: FunnelType):
        """Create default pages for funnel type."""
        funnel = self.funnels[funnel_id]
        
        if funnel_type == FunnelType.WEBINAR:
            self.add_page(funnel_id, "Registration Page", "landing", {"cta": "Register for Free"})
            self.add_page(funnel_id, "Confirmation Page", "confirmation", {})
        elif funnel_type == FunnelType.PRODUCT_LAUNCH:
            self.add_page(funnel_id, "Launch Page", "landing", {"cta": "Learn More"})
            self.add_page(funnel_id, "Sales Page", "sales", {"cta": "Get Access"})
        elif funnel_type == FunnelType.ECOMMERCE:
            self.add_page(funnel_id, "Product Page", "product", {"cta": "Add to Cart"})
            self.add_page(funnel_id, "Checkout", "checkout", {})
    
    def add_page(
        self,
        funnel_id: str,
        title: str,
        page_type: str,
        config: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Add a page to funnel.
        
        Args:
            funnel_id: Funnel ID
            title: Page title
            page_type: Type of page (landing, sales, checkout, etc.)
            config: Page configuration
            
        Returns:
            Created page
        """
        if funnel_id not in self.funnels:
            raise ValueError(f"Funnel {funnel_id} not found")
        
        page = {
            "id": f"page_{int(datetime.now().timestamp())}",
            "funnel_id": funnel_id,
            "title": title,
            "type": page_type,
            "config": config,
            "elements": [],
            "created_at": datetime.now().isoformat()
        }
        
        self.funnels[funnel_id]["pages"].append(page)
        return page
    
    def add_form(
        self,
        funnel_id: str,
        page_id: str,
        fields: List[str],
        submit_text: str = "Submit"
    ) -> Dict[str, Any]:
        """
        Add form to page.
        
        Args:
            funnel_id: Funnel ID
            page_id: Page ID
            fields: List of field names
            submit_text: Submit button text
            
        Returns:
            Created form
        """
        form = {
            "id": f"form_{int(datetime.now().timestamp())}",
            "page_id": page_id,
            "fields": fields,
            "submit_text": submit_text,
            "conversions": 0
        }
        
        self.funnels[funnel_id]["forms"].append(form)
        return form
    
    def create_email_sequence(
        self,
        funnel_id: str,
        subject: str,
        emails_count: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Create email sequence for funnel.
        
        Args:
            funnel_id: Funnel ID
            subject: Email sequence subject
            emails_count: Number of emails in sequence
            
        Returns:
            Created email sequence
        """
        # Import here to avoid circular imports
        from builder.copywriter import CopyWriter
        
        copywriter = CopyWriter()
        sequence = []
        
        for i in range(emails_count):
            email = {
                "id": f"email_{i+1}",
                "sequence_number": i + 1,
                "subject": f"{subject} - Email {i+1}",
                "body": copywriter.generate_email_body(
                    subject,
                    sequence_number=i + 1,
                    total_emails=emails_count
                ),
                "send_delay_hours": (i + 1) * 24
            }
            sequence.append(email)
        
        self.funnels[funnel_id]["email_sequences"].append({
            "id": f"sequence_{int(datetime.now().timestamp())}",
            "subject": subject,
            "emails": sequence
        })
        
        return sequence
    
    def get_funnel(self, funnel_id: str) -> Optional[Dict]:
        """Get funnel by ID."""
        return self.funnels.get(funnel_id)
    
    def list_funnels(self) -> List[Dict]:
        """List all funnels."""
        return list(self.funnels.values())
    
    def update_funnel(self, funnel_id: str, updates: Dict) -> Dict:
        """Update funnel configuration."""
        if funnel_id not in self.funnels:
            raise ValueError(f"Funnel {funnel_id} not found")
        
        self.funnels[funnel_id].update(updates)
        return self.funnels[funnel_id]
