"""
FunnelForge FastAPI Server

REST API for funnel building, page management, and analytics.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
import uvicorn
from dotenv import load_dotenv
import os
import sys

sys.path.insert(0, "/tmp/funnelforge-build")
from builder.funnel import FunnelBuilder, FunnelType
from builder.copywriter import CopyWriter
from analytics.tracker import AnalyticsTracker

load_dotenv()

app = FastAPI(title="FunnelForge API", version="1.0.0")
builder = FunnelBuilder()
copywriter = CopyWriter()
analytics = AnalyticsTracker()


class CreateFunnelRequest(BaseModel):
    """Request to create funnel."""
    name: str
    type: str
    product_name: str
    target_audience: str
    description: Optional[str] = None


class GenerateCopyRequest(BaseModel):
    """Request to generate copy."""
    type: str
    style: Optional[str] = None
    context: Optional[dict] = None


@app.get("/")
async def root():
    """Root endpoint."""
    return {"name": "FunnelForge", "status": "operational"}


@app.post("/funnels")
async def create_funnel(request: CreateFunnelRequest):
    """Create a new funnel."""
    try:
        funnel_type = FunnelType(request.type)
        funnel = builder.create_funnel(
            name=request.name,
            funnel_type=funnel_type,
            product_name=request.product_name,
            target_audience=request.target_audience,
            description=request.description
        )
        return funnel
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/funnels")
async def list_funnels():
    """List all funnels."""
    return {"funnels": builder.list_funnels()}


@app.get("/funnels/{funnel_id}")
async def get_funnel(funnel_id: str):
    """Get funnel by ID."""
    funnel = builder.get_funnel(funnel_id)
    if not funnel:
        raise HTTPException(status_code=404, detail="Funnel not found")
    return funnel


@app.post("/funnels/{funnel_id}/generate-copy")
async def generate_copy(funnel_id: str, request: GenerateCopyRequest):
    """Generate AI copy for funnel."""
    funnel = builder.get_funnel(funnel_id)
    if not funnel:
        raise HTTPException(status_code=404, detail="Funnel not found")
    
    try:
        if request.type == "headline":
            result = copywriter.generate_headline(
                product=funnel["product_name"],
                audience=funnel["target_audience"],
                style=request.style or "benefit-driven"
            )
            return {"headlines": result}
        elif request.type == "cta":
            result = copywriter.generate_cta(action="Get Access")
            return {"ctas": result}
        else:
            raise HTTPException(status_code=400, detail=f"Unknown copy type: {request.type}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/analytics/{funnel_id}")
async def get_analytics(funnel_id: str):
    """Get funnel analytics."""
    metrics = analytics.get_funnel_metrics(funnel_id)
    if not metrics:
        raise HTTPException(status_code=404, detail="Funnel analytics not found")
    return metrics


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
