# FunnelForge AI - AI Sales Funnel Builder

Build high-converting sales funnels with AI-generated copy, smart analytics, and A/B testing built-in.

## Features

- **AI Copywriting**: Generate headlines, CTAs, email sequences with OpenAI
- **Landing Page Builder**: Drag-and-drop templates with pre-optimized designs
- **Conversion Tracking**: Monitor funnel metrics and conversion rates
- **A/B Testing**: Split test pages and analyze results automatically
- **Email Sequences**: Auto-generated follow-up sequences
- **Payment Integration**: Stripe integration for checkout flows
- **Analytics Dashboard**: Real-time conversion tracking and attribution

## System Requirements

- Python 3.9+
- PostgreSQL database
- Stripe account (for payments)
- OpenAI API key
- SMTP email service

## Installation

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Setup database:
   ```bash
   python setup_db.py
   ```

3. Configure:
   ```bash
   cp .env.example .env
   # Add API keys and credentials
   ```

4. Start server:
   ```bash
   python -m uvicorn api.server:app --reload
   ```

## Usage

### Create Funnel
```bash
curl -X POST http://localhost:8000/funnels \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Product Launch",
    "type": "webinar",
    "product_name": "My SaaS",
    "target_audience": "Entrepreneurs"
  }'
```

### Generate AI Copy
```bash
curl -X POST http://localhost:8000/funnels/{id}/generate-copy \
  -H "Content-Type: application/json" \
  -d '{"type": "headline", "style": "benefit-driven"}'
```

### API Endpoints

- **POST /funnels** - Create funnel
- **GET /funnels** - List funnels
- **POST /funnels/{id}/pages** - Add landing page
- **POST /funnels/{id}/generate-copy** - Generate AI copy
- **GET /analytics/{funnel_id}** - Get analytics
- **POST /ab-test** - Create A/B test

## Funnel Types

- **Webinar**: Free webinar registration and follow-up
- **Product Launch**: New product introduction
- **Ecommerce**: Product pages with checkout
- **Lead Gen**: Lead magnet and email capture
- **Membership**: Membership signup and onboarding
- **VSL**: Video sales letter sequence

## Configuration

Edit .env:
- `OPENAI_API_KEY`: OpenAI API key
- `STRIPE_KEY`: Stripe API key
- `DATABASE_URL`: PostgreSQL connection
- `SMTP_HOST`: Email service host

## Analytics Metrics

- Conversion rate
- Cost per lead
- Cost per sale
- Email open rate
- Click-through rate
- Landing page bounce rate
- Funnel stage dropoff

## License

Commercial License ($1,899/month subscription)
