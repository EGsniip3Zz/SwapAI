"""LegalDraft AI API module."""
