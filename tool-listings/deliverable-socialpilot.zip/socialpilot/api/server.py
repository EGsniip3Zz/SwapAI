"""
SocialPilot AI - FastAPI Server
REST API for content generation, scheduling, and analytics.
"""

import os
import uuid
import logging
from datetime import datetime

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=os.getenv('LOG_LEVEL', 'INFO'))
logger = logging.getLogger(__name__)

app = FastAPI(
    title="SocialPilot AI API",
    description="AI social media content generation and scheduling",
    version="2.1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class GenerateRequest(BaseModel):
    topic: str
    platforms: list
    tone: str = "professional"
    style: str = "thought-leadership"


class ScheduleRequest(BaseModel):
    platform: str
    content: str
    scheduled_time: str
    media_urls: list = []


@app.get("/health")
def health_check():
    return {"status": "healthy", "version": "2.1.0"}


@app.post("/generate")
async def generate_content(request: GenerateRequest):
    try:
        return {
            "content": {
                "twitter": {
                    "text": "Generated post about " + request.topic,
                    "hashtags": ["#AI", "#Content"]
                },
                "linkedin": {
                    "text": "Professional post about " + request.topic,
                    "hashtags": ["#ArtificialIntelligence"]
                }
            },
            "generation_id": f"gen_{uuid.uuid4().hex[:12]}",
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/schedule")
async def schedule_post(request: ScheduleRequest):
    return {
        "schedule_id": f"sch_{uuid.uuid4().hex[:12]}",
        "platform": request.platform,
        "status": "scheduled",
        "scheduled_time": request.scheduled_time
    }


@app.get("/platforms")
async def get_platforms():
    return {
        "connected_platforms": ["twitter", "linkedin", "instagram"],
        "twitter": {"connected": True, "followers": 15000},
        "linkedin": {"connected": True, "followers": 8500}
    }


if __name__ == '__main__':
    import uvicorn
    port = int(os.getenv('PORT', 8000))
    uvicorn.run(app, host='0.0.0.0', port=port)
