"""
SocialPilot AI - Content Generation Module
AI-powered social media post generation with platform-specific optimization.
"""

import os
import json
import logging
from typing import List, Dict, Any

import openai
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)
openai.api_key = os.getenv('OPENAI_API_KEY')

# Platform constraints
PLATFORM_CONSTRAINTS = {
    'twitter': {
        'max_length': 280,
        'supports_media': True,
        'supports_hashtags': True,
        'max_hashtags': 10
    },
    'linkedin': {
        'max_length': 3000,
        'supports_media': True,
        'supports_hashtags': True,
        'max_hashtags': 5
    },
    'instagram': {
        'max_length': 2200,
        'supports_media': True,
        'supports_hashtags': True,
        'max_hashtags': 30
    },
    'facebook': {
        'max_length': 63206,
        'supports_media': True,
        'supports_hashtags': False,
        'max_hashtags': 0
    }
}

TONE_TEMPLATES = {
    'professional': 'professional and business-focused',
    'casual': 'casual and friendly',
    'humorous': 'witty and humorous',
    'inspirational': 'motivational and uplifting',
    'educational': 'informative and educational'
}

STYLE_TEMPLATES = {
    'thought-leadership': 'Share industry insights and expert perspectives',
    'entertainment': 'Create engaging and shareable content',
    'educational': 'Provide helpful tips, how-tos, or educational content',
    'promotional': 'Highlight products, services, or special offers',
    'news': 'Share relevant industry news and updates',
    'engagement': 'Ask questions or create engaging conversations'
}


class ContentGenerator:
    """Generate AI-powered social media content"""
    
    def __init__(self):
        self.model = "gpt-3.5-turbo"
    
    def generate_for_platforms(
        self,
        topic: str,
        platforms: List[str],
        tone: str = 'professional',
        style: str = 'thought-leadership',
        hashtags_count: int = 3,
        include_image_prompt: bool = False
    ) -> Dict[str, Any]:
        """Generate platform-specific content for a topic"""
        
        content = {}
        
        for platform in platforms:
            if platform.lower() not in PLATFORM_CONSTRAINTS:
                logger.warning(f"Unsupported platform: {platform}")
                continue
            
            platform_content = self.generate_for_platform(
                topic=topic,
                platform=platform.lower(),
                tone=tone,
                style=style,
                hashtags_count=hashtags_count,
                include_image_prompt=include_image_prompt
            )
            
            if platform_content:
                content[platform.lower()] = platform_content
        
        return content
    
    def generate_for_platform(
        self,
        topic: str,
        platform: str,
        tone: str,
        style: str,
        hashtags_count: int,
        include_image_prompt: bool
    ) -> Dict[str, Any]:
        """Generate content for a specific platform"""
        
        constraints = PLATFORM_CONSTRAINTS.get(platform.lower())
        if not constraints:
            return None
        
        prompt = self._build_prompt(
            topic=topic,
            platform=platform,
            tone=tone,
            style=style,
            hashtags_count=min(hashtags_count, constraints['max_hashtags']),
            max_length=constraints['max_length']
        )
        
        try:
            response = openai.ChatCompletion.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert social media content creator."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=500
            )
            
            response_text = response.choices[0].message.content
            
            # Parse the response (should be JSON)
            import json
            import re
            
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                content = json.loads(json_match.group())
                
                if include_image_prompt:
                    content['image_prompt'] = self._generate_image_prompt(topic, platform)
                
                return content
            
            return {
                'text': response_text,
                'hashtags': [],
                'character_count': len(response_text)
            }
        
        except Exception as e:
            logger.error(f"Generation error: {e}")
            return None
    
    def _build_prompt(self, topic: str, platform: str, tone: str, style: str, 
                     hashtags_count: int, max_length: int) -> str:
        """Build generation prompt for OpenAI"""
        
        tone_desc = TONE_TEMPLATES.get(tone.lower(), 'professional')
        style_desc = STYLE_TEMPLATES.get(style.lower(), 'Share insights')
        
        return f"""
        Create a {platform} post about: {topic}
        
        Requirements:
        - Tone: {tone_desc}
        - Style: {style_desc}
        - Max length: {max_length} characters
        - Include {hashtags_count} relevant hashtags
        - Make it engaging and shareable
        
        Return as JSON:
        {{
            "text": "Post content here",
            "hashtags": ["#tag1", "#tag2"],
            "character_count": 150
        }}
        """
    
    def _generate_image_prompt(self, topic: str, platform: str) -> str:
        """Generate image prompt for visual content"""
        return f"Create a {platform}-optimized visual for a post about {topic}"
    
    def generate_hashtags(self, topic: str, platform: str, count: int = 5) -> List[str]:
        """Generate relevant hashtags for a topic"""
        try:
            prompt = f"Generate {count} relevant hashtags for a {platform} post about '{topic}'. Return only hashtags, comma-separated."
            
            response = openai.ChatCompletion.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=100
            )
            
            hashtags_text = response.choices[0].message.content
            hashtags = [tag.strip() for tag in hashtags_text.split(',')]
            
            return hashtags[:count]
        except Exception as e:
            logger.error(f"Hashtag generation error: {e}")
            return []


if __name__ == '__main__':
    generator = ContentGenerator()
    
    # Test content generation
    content = generator.generate_for_platforms(
        topic='Artificial Intelligence in Business',
        platforms=['twitter', 'linkedin'],
        tone='professional',
        style='thought-leadership'
    )
    
    import json
    print(json.dumps(content, indent=2))
