# SocialPilot AI - AI Social Media Content Generator

**Subscription: $799/month**

**Automated AI-powered social media content creation and scheduling. Generate platform-optimized posts, manage multiple accounts, and track analytics from one dashboard.**

## Overview

SocialPilot AI generates engaging, platform-specific social media content using OpenAI's latest models. Integrates with Twitter, Instagram, LinkedIn, and Facebook for automated scheduling and publishing.

**Pricing:** $799/month subscription
**Licensing:** Multi-account management, unlimited posts
**Platforms:** Twitter, Instagram, LinkedIn, Facebook, TikTok
**Included:** Content generation, scheduling, analytics, 30-day content calendar

## Requirements

- Python 3.9+
- OpenAI API key
- Platform API credentials (Twitter, Instagram, LinkedIn)
- Redis 6.0+ (for task queue)
- 4GB RAM minimum

## Installation & Setup

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Environment Configuration

```bash
cp .env.example .env
```

Edit `.env` with your credentials:

```
OPENAI_API_KEY=sk-your-key
TWITTER_API_KEY=your_twitter_key
TWITTER_API_SECRET=your_twitter_secret
TWITTER_ACCESS_TOKEN=your_access_token
TWITTER_ACCESS_SECRET=your_access_secret

INSTAGRAM_ACCESS_TOKEN=your_instagram_token
LINKEDIN_TOKEN=your_linkedin_token

REDIS_URL=redis://localhost:6379

PORT=8000
```

### 3. Start Redis

```bash
redis-server
```

### 4. Start the Application

```bash
# Terminal 1: API Server
python api/server.py

# Terminal 2: Celery Worker
celery -A scheduler worker --loglevel=info

# Terminal 3: Scheduler
python scheduler.py
```

## API Endpoints

### Generate Content
```
POST /generate
Content-Type: application/json

{
    "topic": "AI productivity tools",
    "platforms": ["twitter", "linkedin"],
    "tone": "professional",
    "style": "thought-leadership",
    "hashtags_count": 3,
    "include_image_prompt": true
}

Response:
{
    "content": {
        "twitter": {
            "text": "Excited about the latest AI...",
            "hashtags": ["#AI", "#Productivity"],
            "character_count": 280
        },
        "linkedin": {
            "text": "Longer form professional post...",
            "hashtags": ["#ArtificialIntelligence"],
            "image_prompt": "Professional workspace..."
        }
    },
    "generation_id": "gen_xyz123"
}
```

### Schedule Post
```
POST /schedule
Content-Type: application/json

{
    "platform": "twitter",
    "content": "Your post text here",
    "scheduled_time": "2025-02-20T14:00:00Z",
    "media_urls": []
}

Response:
{
    "schedule_id": "sch_xyz123",
    "platform": "twitter",
    "status": "scheduled",
    "scheduled_time": "2025-02-20T14:00:00Z"
}
```

### Get Analytics
```
GET /analytics?start_date=2025-02-01&end_date=2025-02-28

Response:
{
    "period": "2025-02-01 to 2025-02-28",
    "platforms": {
        "twitter": {
            "posts": 15,
            "impressions": 45000,
            "engagement_rate": 0.034,
            "followers_gained": 120
        },
        "linkedin": {
            "posts": 8,
            "impressions": 12500,
            "engagement_rate": 0.087,
            "followers_gained": 45
        }
    },
    "top_post": {
        "platform": "linkedin",
        "content": "...",
        "engagement": 2340
    }
}
```

### Get Platforms
```
GET /platforms

Response:
{
    "connected_platforms": ["twitter", "linkedin", "instagram"],
    "twitter": {
        "connected": true,
        "handle": "@yourhandle",
        "followers": 15000
    },
    "linkedin": {
        "connected": true,
        "profile": "Your Profile Name",
        "followers": 8500
    },
    "instagram": {
        "connected": true,
        "handle": "@yourhandle",
        "followers": 25000
    }
}
```

## Features

### Content Generation

- **AI-Powered:** Uses GPT-4 for high-quality content
- **Platform-Specific:** Optimized for each platform's format/length
- **Multiple Styles:** 
  - Thought-leadership
  - Entertainment
  - Educational
  - Promotional
  - News
  - Engagement-focused

### Scheduling

- **Optimal Timing:** AI recommends best posting times
- **Content Calendar:** 30-day view and planning
- **Recurring Posts:** Set up weekly/monthly schedules
- **Bulk Scheduling:** Upload CSV with 100+ posts

### Analytics

- **Real-time Metrics:** Impressions, engagement, reach
- **Audience Insights:** Demographics, interests, growth
- **Performance Tracking:** Top performing content
- **ROI Calculation:** Link tracking and conversions

## Usage Examples

### Python Client

```python
import requests

API_URL = 'http://localhost:8000'

# Generate content
response = requests.post(
    f'{API_URL}/generate',
    json={
        'topic': 'Machine Learning',
        'platforms': ['twitter', 'linkedin'],
        'tone': 'educational'
    }
)

content = response.json()['content']

# Schedule on Twitter
schedule_response = requests.post(
    f'{API_URL}/schedule',
    json={
        'platform': 'twitter',
        'content': content['twitter']['text'],
        'scheduled_time': '2025-02-20T09:00:00Z'
    }
)

print(f"Scheduled post: {schedule_response.json()['schedule_id']}")
```

### Content Generation Styles

```python
styles = [
    'thought-leadership',   # Industry insights
    'entertainment',        # Funny, engaging
    'educational',          # How-to, tips
    'promotional',          # Product/service
    'news',                 # Industry news
    'engagement'            # Questions, polls
]

for style in styles:
    requests.post(f'{API_URL}/generate', json={
        'topic': 'AI',
        'style': style
    })
```

## Platform-Specific Features

### Twitter
- Tweet length optimization (280 chars)
- Thread support
- Media attachment
- Hashtag recommendations
- Engagement tracking

### LinkedIn
- Long-form posts (3,000+ chars)
- Professional tone
- Article sharing
- Document uploads
- Audience targeting

### Instagram
- Hashtag optimization (30 max)
- Caption formatting
- Image prompt generation
- Story ideas
- Carousel post suggestions

### Facebook
- Community-focused content
- Event promotion
- Link preview optimization
- Cross-posting from Instagram

## Task Scheduling with Celery

The scheduler uses Celery for background tasks:

```python
# In generate.py
from celery import shared_task

@shared_task
def generate_daily_content():
    """Generate content every morning"""
    topics = get_trending_topics()
    for topic in topics:
        generate_post(topic)
```

Schedule with cron:

```python
# In scheduler.py
from celery.schedules import crontab

app.conf.beat_schedule = {
    'generate-morning-content': {
        'task': 'generate.daily_content',
        'schedule': crontab(hour=6, minute=0),  # 6 AM
    },
    'fetch-analytics': {
        'task': 'generate.fetch_analytics',
        'schedule': crontab(hour=23, minute=0),  # 11 PM
    },
}
```

## Integration Examples

### Bulk Import Scheduling

```bash
# Create posts.csv:
# topic,platform,scheduled_time
# Python Tips,twitter,2025-02-20T09:00:00Z
# Python Tips,linkedin,2025-02-20T10:00:00Z
# Marketing Strategy,twitter,2025-02-21T09:00:00Z

python bulk_schedule.py posts.csv
```

### Webhook for Real-time Analytics

```python
@app.post("/webhook/twitter-engagement")
async def twitter_engagement(data: dict):
    # Receives real-time engagement metrics
    update_analytics(data)
    return {"status": "received"}
```

## Deployment

### Docker Deployment

```dockerfile
FROM python:3.9
WORKDIR /app
RUN apt-get update && apt-get install -y redis-server
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .

CMD ["bash", "-c", "redis-server --daemonize yes && python api/server.py"]
```

### Docker Compose

```yaml
version: '3.8'
services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      REDIS_URL: redis://redis:6379
    depends_on:
      - redis
  
  worker:
    build: .
    command: celery -A scheduler worker
    depends_on:
      - redis
  
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
```

### Production Notes

- Use systemd for service management
- Run workers in supervisor
- Enable HTTPS for API
- Set up SSL certificates
- Configure CORS properly
- Monitor Redis memory usage

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Redis connection failed" | Ensure Redis is running |
| "Invalid API key" | Check OPENAI_API_KEY in .env |
| "Platform not connected" | Verify API credentials |
| "Task queue error" | Check Celery worker logs |

## License & Support

License: SaaS Subscription ($799/month)
Features: Multi-account, unlimited posts
Support: 24/7 email + chat support
Training: Included onboarding call
Updates: Continuous feature releases

Email: support@socialpilot.ai
Docs: https://docs.socialpilot.ai
Status: https://status.socialpilot.ai

## Version History

- v2.1.0 - TikTok integration (Feb 2025)
- v2.0.0 - Redesigned scheduler
- v1.5.0 - Analytics dashboard
- v1.0.0 - Initial release
