"""
MealGenius Meal Planning Engine

Generates AI-powered 7-day meal plans with nutrition tracking.
"""

import json
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import openai
import pandas as pd
from dotenv import load_dotenv
import os


class MealPlanner:
    """Generates meal plans using AI."""
    
    def __init__(self):
        """Initialize meal planner."""
        load_dotenv()
        self.api_key = os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("OPENAI_API_KEY not found")
        openai.api_key = self.api_key
        self.recipes = self._load_recipes()
    
    def _load_recipes(self) -> List[Dict]:
        """Load recipe database."""
        recipe_file = os.path.join(os.path.dirname(__file__), "data", "recipes.json")
        if os.path.exists(recipe_file):
            with open(recipe_file, 'r') as f:
                return json.load(f)
        return []
    
    def generate_plan(
        self,
        servings: int = 2,
        budget: float = 100,
        dietary_preferences: Optional[List[str]] = None,
        restrictions: Optional[List[str]] = None,
        days: int = 7,
        max_prep_time: int = 60
    ) -> Dict[str, Any]:
        """
        Generate a meal plan.
        
        Args:
            servings: Number of servings per meal
            budget: Total weekly budget
            dietary_preferences: e.g., ['vegetarian', 'vegan']
            restrictions: e.g., ['no nuts', 'no shellfish']
            days: Number of days to plan
            max_prep_time: Maximum prep time in minutes
            
        Returns:
            Dictionary with meal plan and shopping list
        """
        dietary_preferences = dietary_preferences or []
        restrictions = restrictions or []
        
        # Build prompt for meal planning
        dietary_str = ", ".join(dietary_preferences) if dietary_preferences else "none"
        restrictions_str = ", ".join(restrictions) if restrictions else "none"
        
        prompt = f"""Generate a {days}-day meal plan with these requirements:
- Servings per meal: {servings}
- Total budget: ${budget}
- Dietary preferences: {dietary_str}
- Restrictions: {restrictions_str}
- Max prep time per meal: {max_prep_time} minutes

Format response as JSON with this structure:
{{
  "meals": [
    {{"date": "YYYY-MM-DD", "breakfast": "...", "lunch": "...", "dinner": "...", "snack": "..."}}
  ],
  "reasoning": "why this plan works for the requirements"
}}"""
        
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a professional nutritionist and meal planner. Always respond with valid JSON."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=2000
            )
            
            response_text = response.choices[0].message.content
            
            # Parse JSON response
            meal_data = json.loads(response_text)
            
            return {
                "status": "success",
                "meals": meal_data.get("meals", []),
                "reasoning": meal_data.get("reasoning", ""),
                "servings": servings,
                "dietary_preferences": dietary_preferences,
                "restrictions": restrictions
            }
        
        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse meal plan response: {e}")
        except Exception as e:
            raise Exception(f"Meal plan generation failed: {str(e)}")
    
    def calculate_nutrition(self, meal_name: str) -> Dict[str, float]:
        """
        Estimate nutrition for a meal using AI.
        
        Args:
            meal_name: Name of the meal
            
        Returns:
            Nutrition information
        """
        prompt = f"""Estimate nutrition info for this meal: {meal_name}
Provide: calories, protein(g), carbs(g), fat(g), fiber(g)
Format: JSON with keys: calories, protein, carbs, fat, fiber"""
        
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
                max_tokens=200
            )
            
            response_text = response.choices[0].message.content
            nutrition = json.loads(response_text)
            
            return {
                "calories": nutrition.get("calories", 0),
                "protein": nutrition.get("protein", 0),
                "carbs": nutrition.get("carbs", 0),
                "fat": nutrition.get("fat", 0),
                "fiber": nutrition.get("fiber", 0)
            }
        except Exception as e:
            print(f"Nutrition calculation failed: {e}")
            return {"calories": 0, "protein": 0, "carbs": 0, "fat": 0, "fiber": 0}
    
    def get_recipe(self, recipe_id: str) -> Optional[Dict]:
        """Get recipe by ID."""
        for recipe in self.recipes:
            if recipe.get("id") == recipe_id:
                return recipe
        return None
    
    def list_recipes(self, dietary: Optional[str] = None) -> List[Dict]:
        """List recipes, optionally filtered."""
        if not dietary:
            return self.recipes
        
        return [r for r in self.recipes if dietary.lower() in [d.lower() for d in r.get("dietary_tags", [])]]
