"""MealGenius API module."""
