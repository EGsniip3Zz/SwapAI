"""
MealGenius Flask API Server

Endpoints for meal planning, grocery lists, and recipe management.
"""

from flask import Flask, request, jsonify
from dotenv import load_dotenv
import os
import sys

sys.path.insert(0, "/tmp/mealgenius-build")
from planner import MealPlanner
from grocery import GroceryListGenerator

load_dotenv()

app = Flask(__name__)
planner = MealPlanner()
grocery_gen = GroceryListGenerator()


@app.route('/')
def root():
    """Root endpoint."""
    return jsonify({"name": "MealGenius", "status": "operational"})


@app.route('/plan', methods=['POST'])
def generate_meal_plan():
    """Generate a meal plan."""
    try:
        data = request.get_json()
        
        result = planner.generate_plan(
            servings=data.get('servings', 2),
            budget=data.get('budget', 100),
            dietary_preferences=data.get('dietary_preferences', []),
            restrictions=data.get('restrictions', []),
            days=data.get('days', 7),
            max_prep_time=data.get('max_prep_time', 60)
        )
        
        return jsonify(result), 200
    
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route('/grocery-list', methods=['GET'])
def get_grocery_list():
    """Get optimized grocery list from current meal plan."""
    try:
        plan = request.args.get('plan')
        budget = request.args.get('budget', 100, type=float)
        
        if not plan:
            return jsonify({"error": "plan parameter required"}), 400
        
        import json
        meals = json.loads(plan)
        
        grocery_list = grocery_gen.aggregate_ingredients(meals)
        optimized = grocery_gen.optimize_budget(grocery_list, budget)
        formatted = grocery_gen.generate_shopping_list(optimized['list'])
        
        return jsonify({
            "status": optimized['status'],
            "shopping_list": optimized['list'],
            "total_cost": optimized.get('total_cost'),
            "formatted_list": formatted
        }), 200
    
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route('/recipes', methods=['GET'])
def list_recipes():
    """Get recipe list."""
    try:
        dietary = request.args.get('dietary')
        recipes = planner.list_recipes(dietary)
        return jsonify({"recipes": recipes, "count": len(recipes)}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route('/recipes/<recipe_id>', methods=['GET'])
def get_recipe(recipe_id):
    """Get specific recipe."""
    try:
        recipe = planner.get_recipe(recipe_id)
        if recipe:
            return jsonify(recipe), 200
        return jsonify({"error": "Recipe not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route('/nutrition', methods=['POST'])
def get_nutrition():
    """Get nutrition info for a meal."""
    try:
        data = request.get_json()
        meal = data.get('meal')
        
        if not meal:
            return jsonify({"error": "meal parameter required"}), 400
        
        nutrition = planner.calculate_nutrition(meal)
        return jsonify({"meal": meal, "nutrition": nutrition}), 200
    
    except Exception as e:
        return jsonify({"error": str(e)}), 400


if __name__ == '__main__':
    app.run(debug=True, port=5000)
