"""
MealGenius Grocery List Generator

Aggregates ingredients from meal plan, deduplicates, and estimates costs.
"""

import json
from typing import Dict, List, Any, Optional
import pandas as pd


class GroceryListGenerator:
    """Generates and optimizes shopping lists."""
    
    # Price estimates for common ingredients
    PRICE_DATABASE = {
        "chicken breast": 8.99,
        "ground beef": 6.99,
        "salmon": 12.99,
        "broccoli": 2.49,
        "spinach": 3.99,
        "carrots": 1.99,
        "rice": 2.49,
        "pasta": 1.49,
        "olive oil": 8.99,
        "eggs": 4.99,
        "milk": 3.99,
        "cheese": 5.99,
        "tomatoes": 3.99,
        "bell pepper": 2.99,
        "onion": 0.99,
        "garlic": 4.99,
        "beans": 1.49,
        "lentils": 2.99,
        "tofu": 3.99,
        "tempeh": 4.99,
        "yogurt": 5.99,
        "bread": 3.99,
        "butter": 5.99,
        "salt": 2.99,
        "pepper": 4.99
    }
    
    def __init__(self):
        """Initialize grocery list generator."""
        pass
    
    def aggregate_ingredients(self, meals: List[Dict[str, str]]) -> List[Dict[str, Any]]:
        """
        Extract and aggregate ingredients from meal list.
        
        Args:
            meals: List of meals (dict with breakfast, lunch, dinner, snack)
            
        Returns:
            List of aggregated ingredients with quantities
        """
        ingredients = {}
        
        for meal_day in meals:
            for meal_type in ["breakfast", "lunch", "dinner", "snack"]:
                meal_name = meal_day.get(meal_type, "")
                if not meal_name:
                    continue
                
                # Extract ingredients from meal name
                extracted = self._extract_ingredients(meal_name)
                
                for ingredient, quantity in extracted.items():
                    if ingredient not in ingredients:
                        ingredients[ingredient] = 0
                    ingredients[ingredient] += quantity
        
        return self._format_ingredients(ingredients)
    
    def _extract_ingredients(self, meal_name: str) -> Dict[str, float]:
        """
        Extract likely ingredients from meal name.
        
        This is a simplified version - in production use NLP or API.
        """
        ingredients = {}
        meal_lower = meal_name.lower()
        
        # Simple keyword matching
        if "chicken" in meal_lower:
            ingredients["chicken breast"] = 0.5  # lbs
        if "beef" in meal_lower:
            ingredients["ground beef"] = 0.5
        if "salmon" in meal_lower or "fish" in meal_lower:
            ingredients["salmon"] = 0.33
        if "rice" in meal_lower:
            ingredients["rice"] = 0.5  # cups
        if "pasta" in meal_lower:
            ingredients["pasta"] = 0.5  # cups
        if "bread" in meal_lower:
            ingredients["bread"] = 2  # slices
        if "salad" in meal_lower:
            ingredients["spinach"] = 0.5  # cups
            ingredients["tomatoes"] = 0.5  # qty
        if "vegetables" in meal_lower or "veggie" in meal_lower:
            ingredients["broccoli"] = 1  # cup
            ingredients["carrots"] = 1  # cup
        if "eggs" in meal_lower or "omelette" in meal_lower:
            ingredients["eggs"] = 3  # count
        if "yogurt" in meal_lower:
            ingredients["yogurt"] = 1  # cup
        if "cheese" in meal_lower:
            ingredients["cheese"] = 0.25  # lbs
        
        return ingredients
    
    def _format_ingredients(self, ingredients: Dict[str, float]) -> List[Dict[str, Any]]:
        """Format ingredients with units and costs."""
        formatted = []
        
        for ingredient, quantity in ingredients.items():
            # Determine unit
            if ingredient in ["eggs"]:
                unit = "count"
            elif ingredient in ["bread"]:
                unit = "slices"
            elif ingredient in ["pasta", "rice"]:
                unit = "cups"
            elif ingredient in ["yogurt"]:
                unit = "cups"
            else:
                unit = "lbs"
            
            # Get price
            price = self.PRICE_DATABASE.get(ingredient.lower(), 5.99)
            estimated_cost = price * quantity
            
            formatted.append({
                "ingredient": ingredient,
                "quantity": quantity,
                "unit": unit,
                "price_per_unit": price,
                "estimated_cost": estimated_cost
            })
        
        return sorted(formatted, key=lambda x: x["estimated_cost"], reverse=True)
    
    def optimize_budget(self, grocery_list: List[Dict], target_cost: float) -> Dict[str, Any]:
        """
        Optimize shopping list to fit budget.
        
        Args:
            grocery_list: List of ingredients
            target_cost: Target total cost
            
        Returns:
            Optimized list with suggestions
        """
        total_cost = sum(item["estimated_cost"] for item in grocery_list)
        
        if total_cost <= target_cost:
            return {
                "status": "within_budget",
                "list": grocery_list,
                "total_cost": total_cost,
                "remaining_budget": target_cost - total_cost
            }
        
        # Remove lowest priority items
        optimized = []
        current_cost = 0
        
        for item in sorted(grocery_list, key=lambda x: x["estimated_cost"]):
            if current_cost + item["estimated_cost"] <= target_cost:
                optimized.append(item)
                current_cost += item["estimated_cost"]
            else:
                # Suggest alternatives
                item["alternative"] = self._find_alternative(item, target_cost - current_cost)
        
        return {
            "status": "optimized",
            "list": optimized,
            "total_cost": current_cost,
            "savings": total_cost - current_cost,
            "excluded_items": [i for i in grocery_list if i not in optimized]
        }
    
    def _find_alternative(self, item: Dict, budget_remaining: float) -> Optional[Dict]:
        """Find cheaper alternative for ingredient."""
        # Simplified - in production use a real alternative database
        if item["estimated_cost"] > budget_remaining:
            base_price = item["price_per_unit"] * 0.7
            if base_price <= budget_remaining:
                return {
                    "suggestion": f"Generic brand of {item['ingredient']}",
                    "estimated_cost": base_price
                }
        return None
    
    def generate_shopping_list(self, grocery_list: List[Dict], group_by_section: bool = True) -> str:
        """
        Generate formatted shopping list.
        
        Args:
            grocery_list: List of ingredients
            group_by_section: Group by store section
            
        Returns:
            Formatted shopping list text
        """
        sections = {
            "Produce": ["tomatoes", "onion", "garlic", "carrots", "broccoli", "spinach", "bell pepper"],
            "Proteins": ["chicken", "beef", "salmon", "eggs", "tofu", "tempeh"],
            "Dairy": ["milk", "cheese", "yogurt", "butter"],
            "Pantry": ["rice", "pasta", "beans", "lentils", "salt", "pepper", "oil"],
            "Bread": ["bread"]
        }
        
        output = "SHOPPING LIST\n" + "=" * 40 + "\n\n"
        total = 0
        
        for item in grocery_list:
            cost = item["estimated_cost"]
            total += cost
            output += f"[ ] {item['ingredient']:<20} {item['quantity']:>5} {item['unit']:<10} ${cost:.2f}\n"
        
        output += "\n" + "=" * 40 + "\n"
        output += f"Total Estimated Cost: ${total:.2f}\n"
        
        return output
