# MealGenius - AI Meal Planning & Grocery Optimization

Generate personalized meal plans powered by AI and automatically optimize your grocery list for budget and nutrition.

## Features

- **AI Meal Planning**: Generate 7-day meal plans based on preferences
- **Nutrition Tracking**: Automatic macro and calorie calculations
- **Smart Shopping Lists**: Deduplicated ingredients with cost estimates
- **Budget Optimization**: Find best deals and suggest substitutions
- **Dietary Customization**: Vegan, keto, gluten-free, allergies, etc.
- **Prep Time Filtering**: Show recipes you can actually make

## System Requirements

- Python 3.9+
- OpenAI API key
- 1GB RAM minimum
- Modern web browser

## Installation

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Configure:
   ```bash
   cp .env.example .env
   # Add your OpenAI API key
   ```

3. Start server:
   ```bash
   python -m flask --app api.server run
   ```

4. Access at http://localhost:5000

## Usage

### Generate Meal Plan
```bash
curl -X POST http://localhost:5000/plan \
  -H "Content-Type: application/json" \
  -d '{
    "servings": 2,
    "budget": 100,
    "dietary_preferences": ["vegetarian"],
    "restrictions": ["no nuts"],
    "days": 7
  }'
```

### Get Shopping List
```bash
curl http://localhost:5000/grocery-list
```

### API Endpoints

- **POST /plan** - Generate meal plan
- **GET /grocery-list** - Get aggregated shopping list
- **GET /recipes** - Get recipe database
- **GET /recipes/{id}** - Get recipe details

## Configuration

Edit .env:
- `OPENAI_API_KEY`: Your OpenAI API key
- `BUDGET_CURRENCY`: USD, EUR, GBP
- `DEFAULT_SERVINGS`: Default servings per recipe

## Dietary Options

- Vegan
- Vegetarian
- Keto
- Paleo
- Gluten-Free
- Dairy-Free
- Low-Carb
- High-Protein

## Example Response

```json
{
  "plan": [
    {
      "date": "2024-01-15",
      "breakfast": "Oatmeal with berries",
      "lunch": "Grilled chicken salad",
      "dinner": "Pasta primavera"
    }
  ],
  "shopping_list": [
    {
      "ingredient": "Chicken breast",
      "quantity": 2,
      "unit": "lbs",
      "estimated_cost": 8.99
    }
  ],
  "total_cost": 85.50,
  "nutrition_summary": {
    "calories_per_day": 2000,
    "protein_grams": 100,
    "carbs_grams": 200,
    "fat_grams": 65
  }
}
```

## License

Commercial License
