"""
PixelMorph - Image-to-Video Animation

Converts static images into animated videos using Stable Video Diffusion and frame interpolation.
"""

import argparse
import os
from pathlib import Path
from typing import Optional, Tuple

import torch
from diffusers import StableVideoDiffusionPipeline
from PIL import Image
import cv2
import numpy as np
from dotenv import load_dotenv


class ImageToVideoGenerator:
    """Generates videos from static images using diffusion models."""
    
    SUPPORTED_FORMATS = ['.jpg', '.jpeg', '.png', '.webp', '.bmp']
    OUTPUT_FORMATS = ['mp4', 'webm', 'gif', 'mov']
    
    def __init__(self, device: Optional[str] = None, model_id: Optional[str] = None):
        """
        Initialize the video generator.
        
        Args:
            device: CUDA device (e.g., 'cuda:0'). Auto-detects if None.
            model_id: Hugging Face model ID for SVD
        """
        load_dotenv()
        
        self.device = device or os.getenv("GPU_DEVICE", "cuda:0" if torch.cuda.is_available() else "cpu")
        self.model_id = model_id or os.getenv("MODEL_ID", "stabilityai/stable-video-diffusion-img2vid-xt")
        self.max_frames = int(os.getenv("MAX_FRAMES", "25"))
        self.fps = int(os.getenv("VIDEO_FPS", "30"))
        
        self.pipe = None
        self._initialize_model()
    
    def _initialize_model(self):
        """Load and prepare the diffusion pipeline."""
        try:
            print(f"Loading model: {self.model_id}")
            self.pipe = StableVideoDiffusionPipeline.from_pretrained(
                self.model_id,
                torch_dtype=torch.float16,
                variant="fp16"
            )
            self.pipe.enable_attention_slicing()
            self.pipe = self.pipe.to(self.device)
            print(f"Model loaded on {self.device}")
        except Exception as e:
            print(f"Warning: Could not load GPU pipeline: {e}")
            print("Falling back to CPU")
            self.device = "cpu"
            self.pipe = StableVideoDiffusionPipeline.from_pretrained(self.model_id)
            self.pipe = self.pipe.to(self.device)
    
    def validate_image(self, image_path: str) -> bool:
        """
        Validate image file.
        
        Args:
            image_path: Path to image file
            
        Returns:
            True if valid, False otherwise
        """
        path = Path(image_path)
        
        if not path.exists():
            raise FileNotFoundError(f"Image not found: {image_path}")
        
        if path.suffix.lower() not in self.SUPPORTED_FORMATS:
            raise ValueError(f"Unsupported format: {path.suffix}")
        
        try:
            img = Image.open(path)
            img.verify()
            return True
        except Exception as e:
            raise ValueError(f"Invalid image file: {e}")
    
    def prepare_image(self, image_path: str, size: Tuple[int, int] = (1024, 576)) -> Image.Image:
        """
        Load and prepare image for video generation.
        
        Args:
            image_path: Path to image file
            size: Output size (width, height)
            
        Returns:
            Prepared PIL Image
        """
        self.validate_image(image_path)
        
        img = Image.open(image_path).convert("RGB")
        # Resize maintaining aspect ratio
        img.thumbnail(size, Image.Resampling.LANCZOS)
        
        # Pad to exact size
        new_img = Image.new("RGB", size, color=(0, 0, 0))
        offset = ((size[0] - img.width) // 2, (size[1] - img.height) // 2)
        new_img.paste(img, offset)
        
        return new_img
    
    def generate_video(
        self,
        image_path: str,
        duration: int = 5,
        num_frames: Optional[int] = None,
        num_inference_steps: int = 25
    ) -> list:
        """
        Generate video frames from a static image.
        
        Args:
            image_path: Path to input image
            duration: Desired video duration in seconds
            num_frames: Number of frames (overrides duration calculation)
            num_inference_steps: Diffusion steps (higher = better quality, slower)
            
        Returns:
            List of PIL Images representing video frames
        """
        num_frames = num_frames or min(self.max_frames, int(duration * self.fps))
        num_frames = min(num_frames, self.max_frames)
        
        print(f"Generating {num_frames} frames for {duration}s video")
        
        # Prepare image
        image = self.prepare_image(image_path)
        
        # Generate frames using diffusion pipeline
        with torch.no_grad():
            frames = self.pipe(
                image=image,
                num_inference_steps=num_inference_steps,
                num_frames=num_frames,
                height=576,
                width=1024
            ).frames[0]
        
        return frames
    
    def interpolate_frames(self, frames: list, interpolation_factor: int = 2) -> list:
        """
        Interpolate between frames for smoother motion.
        
        Args:
            frames: List of PIL Images
            interpolation_factor: How many frames to insert between existing frames
            
        Returns:
            Interpolated frame list
        """
        if interpolation_factor <= 1:
            return frames
        
        interpolated = []
        
        for i in range(len(frames) - 1):
            frame1 = np.array(frames[i])
            frame2 = np.array(frames[i + 1])
            
            interpolated.append(frames[i])
            
            # Generate intermediate frames
            for j in range(1, interpolation_factor):
                alpha = j / interpolation_factor
                blended = cv2.addWeighted(frame1, 1 - alpha, frame2, alpha, 0)
                interpolated.append(Image.fromarray(blended.astype('uint8')))
        
        interpolated.append(frames[-1])
        return interpolated
    
    def save_video(
        self,
        frames: list,
        output_path: str,
        format: str = "mp4",
        fps: Optional[int] = None
    ) -> str:
        """
        Save frames as video file.
        
        Args:
            frames: List of PIL Images
            output_path: Path for output file
            format: Output format (mp4, webm, gif, mov)
            fps: Frames per second (uses self.fps if None)
            
        Returns:
            Path to saved video
        """
        fps = fps or self.fps
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        if format == "gif":
            frames[0].save(
                str(output_path),
                save_all=True,
                append_images=frames[1:],
                duration=int(1000 / fps),
                loop=0
            )
            return str(output_path)
        
        # Use OpenCV for video formats
        if not frames:
            raise ValueError("No frames to save")
        
        frame_cv = cv2.cvtColor(np.array(frames[0]), cv2.COLOR_RGB2BGR)
        height, width = frame_cv.shape[:2]
        
        # Setup codec
        if format == "mp4":
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            ext = '.mp4'
        elif format == "webm":
            fourcc = cv2.VideoWriter_fourcc(*'VP90')
            ext = '.webm'
        elif format == "mov":
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            ext = '.mov'
        else:
            raise ValueError(f"Unsupported format: {format}")
        
        if not str(output_path).endswith(ext):
            output_path = output_path.with_suffix(ext)
        
        out = cv2.VideoWriter(str(output_path), fourcc, fps, (width, height))
        
        for frame in frames:
            frame_bgr = cv2.cvtColor(np.array(frame), cv2.COLOR_RGB2BGR)
            out.write(frame_bgr)
        
        out.release()
        return str(output_path)


def main():
    """Command-line interface for video generation."""
    parser = argparse.ArgumentParser(description="Generate videos from images with AI")
    parser.add_argument("--input", required=True, help="Input image path")
    parser.add_argument("--output", default="output.mp4", help="Output video path")
    parser.add_argument("--duration", type=int, default=5, help="Duration in seconds")
    parser.add_argument("--format", choices=ImageToVideoGenerator.OUTPUT_FORMATS, default="mp4")
    parser.add_argument("--fps", type=int, default=30, help="Frames per second")
    parser.add_argument("--interpolate", type=int, default=1, help="Frame interpolation factor")
    parser.add_argument("--steps", type=int, default=25, help="Diffusion inference steps")
    
    args = parser.parse_args()
    
    try:
        generator = ImageToVideoGenerator()
        
        print(f"Generating video from {args.input}")
        frames = generator.generate_video(
            args.input,
            duration=args.duration,
            num_inference_steps=args.steps
        )
        
        if args.interpolate > 1:
            print(f"Interpolating frames (factor: {args.interpolate})")
            frames = generator.interpolate_frames(frames, args.interpolate)
        
        output_path = generator.save_video(frames, args.output, args.format, args.fps)
        print(f"Video saved to {output_path}")
    
    except Exception as e:
        print(f"Error: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
