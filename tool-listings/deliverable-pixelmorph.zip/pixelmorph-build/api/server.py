"""
FastAPI server for PixelMorph image-to-video generation.
"""

import io
import os
from pathlib import Path

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
import uvicorn
from dotenv import load_dotenv

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from animate import ImageToVideoGenerator


load_dotenv()

app = FastAPI(
    title="PixelMorph API",
    description="AI image-to-video animation API",
    version="1.0.0"
)

try:
    generator = ImageToVideoGenerator()
except Exception as e:
    print(f"Initialization error: {e}")


class AnimateRequest(BaseModel):
    """Request for video generation."""
    duration: int = 5
    num_frames: int = 25
    interpolate: int = 1
    format: str = "mp4"


class PreviewRequest(BaseModel):
    """Request for preview generation."""
    duration: int = 3


@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "name": "PixelMorph",
        "version": "1.0.0",
        "status": "operational",
        "gpu": str(generator.device)
    }


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "device": str(generator.device),
        "model": generator.model_id
    }


@app.post("/animate")
async def animate(file: UploadFile = File(...), duration: int = 5, format: str = "mp4"):
    """
    Generate video from uploaded image.
    
    Args:
        file: Image file upload
        duration: Video duration in seconds
        format: Output format (mp4, webm, gif, mov)
        
    Returns:
        Generated video file
    """
    try:
        # Save temporary file
        temp_path = f"/tmp/{file.filename}"
        with open(temp_path, "wb") as f:
            f.write(await file.read())
        
        # Generate video
        frames = generator.generate_video(temp_path, duration=duration)
        
        # Save output
        output_path = f"/tmp/output.{format}"
        video_path = generator.save_video(frames, output_path, format=format)
        
        # Cleanup
        os.remove(temp_path)
        
        return FileResponse(
            path=video_path,
            media_type="video/mp4" if format == "mp4" else "video/webm"
        )
    
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/preview")
async def preview(file: UploadFile = File(...)):
    """
    Generate low-resolution preview video.
    
    Args:
        file: Image file upload
        
    Returns:
        Preview video file
    """
    try:
        temp_path = f"/tmp/{file.filename}"
        with open(temp_path, "wb") as f:
            f.write(await file.read())
        
        # Generate short preview
        frames = generator.generate_video(temp_path, duration=2, num_frames=8)
        
        output_path = "/tmp/preview.mp4"
        video_path = generator.save_video(frames, output_path, format="mp4")
        
        os.remove(temp_path)
        
        return FileResponse(path=video_path, media_type="video/mp4")
    
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/info")
async def get_info():
    """Get API and model information."""
    return {
        "api_version": "1.0.0",
        "model": generator.model_id,
        "device": str(generator.device),
        "max_frames": generator.max_frames,
        "default_fps": generator.fps,
        "supported_formats": ImageToVideoGenerator.OUTPUT_FORMATS,
        "supported_inputs": ImageToVideoGenerator.SUPPORTED_FORMATS
    }


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
