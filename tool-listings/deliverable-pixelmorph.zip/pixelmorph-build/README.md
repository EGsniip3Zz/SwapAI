# PixelMorph - AI Image-to-Video Animation

PixelMorph transforms static images into dynamic, animated videos using Stable Video Diffusion and advanced frame interpolation.

## Features

- **Image-to-Video Generation**: Convert any image into smooth, professional video
- **Frame Interpolation**: Seamless frame generation for fluid motion
- **Multiple Output Formats**: MP4, WebM, and GIF export
- **GPU Acceleration**: Optimized for NVIDIA CUDA
- **Customizable Duration**: Control video length and speed

## System Requirements

- Python 3.10+
- NVIDIA GPU with 8GB+ VRAM (CUDA 11.8+)
- 2GB free disk space
- FFMPEG installed
- 8GB RAM minimum

## Installation

1. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Install FFMPEG:
   ```bash
   # macOS
   brew install ffmpeg
   
   # Ubuntu/Debian
   sudo apt-get install ffmpeg
   
   # Windows
   choco install ffmpeg
   ```

3. Configure environment:
   ```bash
   cp .env.example .env
   # Edit .env with GPU settings
   ```

## Usage

### Command Line
```bash
python animate.py --input image.jpg --duration 5 --output video.mp4
```

### API Server
```bash
python -m uvicorn api.server:app --reload
```

### API Endpoints

- **POST /animate** - Generate video from image
  - Request: `{"image_path": "...", "duration": 5, "num_frames": 25}`
  - Response: Video file

- **POST /preview** - Generate preview (lower resolution)
  - Request: `{"image_path": "..."}`
  - Response: Preview video

- **POST /export** - Export with custom settings
  - Request: `{"video_path": "...", "format": "mp4"}`
  - Response: Exported file

## GPU Requirements

- **Minimum**: NVIDIA RTX 2060 (6GB VRAM)
- **Recommended**: NVIDIA RTX 3080 (10GB VRAM)
- **Optimal**: NVIDIA A100 (40GB VRAM)

## Supported Formats

- **Input**: JPG, PNG, WebP, BMP
- **Output**: MP4, WebM, GIF, MOV

## Configuration

Edit `.env` to customize:
- `MODEL_ID`: Stability AI model ID
- `GPU_DEVICE`: CUDA device (cuda:0, cuda:1, etc.)
- `MAX_FRAMES`: Maximum frames to generate (25 default)
- `VIDEO_FPS`: Output frame rate (30 default)

## Performance Tips

1. Use GPU consistently for best speed
2. Smaller images render faster
3. Batch process multiple images
4. Monitor VRAM during processing

## Troubleshooting

**"CUDA out of memory"**
- Reduce max frames in .env
- Use smaller input images
- Close other GPU applications

**"FFMPEG not found"**
- Install FFMPEG using instructions above
- Add FFMPEG to system PATH

**"Model download failed"**
- Check internet connection
- Verify Hugging Face credentials
- Check disk space

## License

Commercial License - See LICENSE file
