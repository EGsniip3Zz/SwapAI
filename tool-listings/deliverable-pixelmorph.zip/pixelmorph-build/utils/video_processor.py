"""
Video processing utilities for PixelMorph.

Handles frame extraction, interpolation, and video encoding.
"""

import subprocess
from pathlib import Path
from typing import Optional, List

import cv2
import numpy as np
from PIL import Image


class VideoProcessor:
    """Handles video processing operations."""
    
    @staticmethod
    def extract_frames(video_path: str, num_frames: Optional[int] = None) -> List[np.ndarray]:
        """
        Extract frames from video file.
        
        Args:
            video_path: Path to video file
            num_frames: Maximum frames to extract
            
        Returns:
            List of frames as numpy arrays
        """
        cap = cv2.VideoCapture(video_path)
        frames = []
        count = 0
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            
            frames.append(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            count += 1
            
            if num_frames and count >= num_frames:
                break
        
        cap.release()
        return frames
    
    @staticmethod
    def interpolate_linear(frame1: np.ndarray, frame2: np.ndarray, steps: int = 3) -> List[np.ndarray]:
        """
        Linear interpolation between two frames.
        
        Args:
            frame1: First frame
            frame2: Second frame
            steps: Number of intermediate frames
            
        Returns:
            List of interpolated frames
        """
        interpolated = [frame1]
        
        for i in range(1, steps):
            alpha = i / steps
            blended = cv2.addWeighted(
                frame1.astype(float),
                1 - alpha,
                frame2.astype(float),
                alpha,
                0
            )
            interpolated.append(blended.astype(np.uint8))
        
        return interpolated
    
    @staticmethod
    def interpolate_optical_flow(frame1: np.ndarray, frame2: np.ndarray, steps: int = 3) -> List[np.ndarray]:
        """
        Optical flow-based frame interpolation for smoother motion.
        
        Args:
            frame1: First frame
            frame2: Second frame
            steps: Number of intermediate frames
            
        Returns:
            List of interpolated frames
        """
        gray1 = cv2.cvtColor(frame1, cv2.COLOR_RGB2GRAY)
        gray2 = cv2.cvtColor(frame2, cv2.COLOR_RGB2GRAY)
        
        # Calculate optical flow
        flow = cv2.calcOpticalFlowFarneback(
            gray1, gray2,
            None,
            pyr_scale=0.5,
            levels=3,
            winsize=15,
            iterations=3,
            n8=False,
            poly_n=5,
            poly_sigma=1.2,
            flags=0
        )
        
        interpolated = [frame1]
        
        for i in range(1, steps):
            alpha = i / steps
            # Warp frame1 toward frame2 using optical flow
            x, y = np.meshgrid(np.arange(flow.shape[1]), np.arange(flow.shape[0]))
            map_x = (x + flow[..., 0] * alpha).astype(np.float32)
            map_y = (y + flow[..., 1] * alpha).astype(np.float32)
            
            warped = cv2.remap(frame1, map_x, map_y, cv2.INTER_LINEAR)
            interpolated.append(warped)
        
        return interpolated
    
    @staticmethod
    def encode_video(frames: List[np.ndarray], output_path: str, fps: int = 30, codec: str = "mp4v") -> str:
        """
        Encode frames to video file using FFmpeg.
        
        Args:
            frames: List of frames as numpy arrays
            output_path: Output file path
            fps: Frames per second
            codec: Video codec
            
        Returns:
            Path to encoded video
        """
        if not frames:
            raise ValueError("No frames to encode")
        
        height, width = frames[0].shape[:2]
        
        # Use FFmpeg for encoding
        cmd = [
            'ffmpeg',
            '-y',
            '-f', 'rawvideo',
            '-vcodec', 'rawvideo',
            '-s', f'{width}x{height}',
            '-pix_fmt', 'rgb24',
            '-r', str(fps),
            '-i', '-',
            '-c:v', codec,
            '-pix_fmt', 'yuv420p',
            '-q:v', '5',
            output_path
        ]
        
        try:
            proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            
            for frame in frames:
                proc.stdin.write(frame.tobytes())
            
            proc.stdin.close()
            proc.wait()
            
            if proc.returncode != 0:
                raise Exception(f"FFmpeg error: {proc.stderr.read().decode()}")
            
            return output_path
        
        except FileNotFoundError:
            raise Exception("FFmpeg not found. Please install FFmpeg.")
    
    @staticmethod
    def get_video_info(video_path: str) -> dict:
        """
        Get video information using FFprobe.
        
        Args:
            video_path: Path to video file
            
        Returns:
            Dictionary with video metadata
        """
        try:
            cmd = [
                'ffprobe',
                '-v', 'error',
                '-select_streams', 'v:0',
                '-show_entries', 'stream=width,height,r_frame_rate,duration',
                '-of', 'default=noprint_wrappers=1:nokey=1:pairs_sep=,',
                video_path
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                data = result.stdout.strip().split(',')
                return {
                    'width': int(data[0]),
                    'height': int(data[1]),
                    'fps': float(data[2].split('/')[0]) / float(data[2].split('/')[1]) if '/' in data[2] else float(data[2]),
                    'duration': float(data[3]) if len(data) > 3 else 0
                }
        except Exception as e:
            print(f"Error getting video info: {e}")
        
        return {}


class FrameProcessor:
    """Process individual frames."""
    
    @staticmethod
    def denoise(frame: np.ndarray, strength: int = 10) -> np.ndarray:
        """
        Denoise frame using bilateral filter.
        
        Args:
            frame: Input frame
            strength: Denoising strength (1-30)
            
        Returns:
            Denoised frame
        """
        return cv2.bilateralFilter(frame, 9, strength, strength)
    
    @staticmethod
    def enhance_colors(frame: np.ndarray, saturation: float = 1.2) -> np.ndarray:
        """
        Enhance color saturation.
        
        Args:
            frame: Input frame in RGB
            saturation: Saturation multiplier (>1 increases saturation)
            
        Returns:
            Enhanced frame
        """
        hsv = cv2.cvtColor(frame, cv2.COLOR_RGB2HSV).astype(np.float32)
        hsv[:, :, 1] = np.clip(hsv[:, :, 1] * saturation, 0, 255)
        return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB)
    
    @staticmethod
    def adjust_brightness(frame: np.ndarray, factor: float = 1.0) -> np.ndarray:
        """
        Adjust frame brightness.
        
        Args:
            frame: Input frame
            factor: Brightness factor (>1 brightens, <1 darkens)
            
        Returns:
            Adjusted frame
        """
        adjusted = cv2.convertScaleAbs(frame.astype(float) * factor)
        return np.clip(adjusted, 0, 255).astype(np.uint8)
