"""PixelMorph utilities module."""
