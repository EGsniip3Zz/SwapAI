"""
DataForge FastAPI Server

REST API for pipeline management and execution.
"""

import json
from typing import Optional, Dict, Any
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn
from dotenv import load_dotenv
import os

import sys
sys.path.insert(0, "/tmp/dataforge-build")
from pipeline.engine import PipelineEngine

load_dotenv()

app = FastAPI(title="DataForge API", version="1.0.0")
engine = PipelineEngine()

# Storage for pipelines (in-memory for demo)
pipelines = {}


class PipelineConfig(BaseModel):
    """Pipeline configuration model."""
    id: str
    name: str
    nodes: list
    connections: list


class ExecuteRequest(BaseModel):
    """Pipeline execution request."""
    pipeline_id: str
    variables: Optional[Dict[str, Any]] = {}


@app.get("/")
async def root():
    """Root endpoint."""
    return {"name": "DataForge", "status": "operational"}


@app.post("/pipelines")
async def create_pipeline(config: PipelineConfig):
    """Create a new pipeline."""
    pipelines[config.id] = config.dict()
    return {"id": config.id, "status": "created"}


@app.get("/pipelines")
async def list_pipelines():
    """List all pipelines."""
    return {"pipelines": list(pipelines.keys()), "count": len(pipelines)}


@app.get("/pipelines/{pipeline_id}")
async def get_pipeline(pipeline_id: str):
    """Get pipeline configuration."""
    if pipeline_id not in pipelines:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    return pipelines[pipeline_id]


@app.post("/pipelines/{pipeline_id}/run")
async def run_pipeline(pipeline_id: str, request: ExecuteRequest):
    """Execute a pipeline."""
    if pipeline_id not in pipelines:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    
    try:
        context = {
            **request.variables,
            "openai_api_key": os.getenv("OPENAI_API_KEY"),
            "database_url": os.getenv("DATABASE_URL")
        }
        result = engine.execute(pipelines[pipeline_id], context)
        return result
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/nodes")
async def list_nodes():
    """List available node types."""
    return {
        "nodes": [
            "InputCSV", "InputDatabase", "CleanData", "TransformData",
            "AIEnrich", "FilterRows", "OutputCSV", "OutputAPI"
        ]
    }


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
