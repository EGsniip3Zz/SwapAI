"""
DataForge Node Definitions

Pre-built nodes for common data pipeline operations.
"""

import csv
import json
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
import pandas as pd
import openai


class Node(ABC):
    """Base class for all pipeline nodes."""
    
    def __init__(self, config: Dict[str, Any]):
        """Initialize node with configuration."""
        self.id = config.get("id", "unknown")
        self.type = config.get("type")
        self.config = config
    
    @abstractmethod
    def execute(self, input_data: Dict[str, Any], context: Dict) -> Any:
        """Execute the node logic."""
        pass


class InputCSV(Node):
    """Load data from CSV file."""
    
    def execute(self, input_data: Dict[str, Any], context: Dict) -> Dict:
        """Load CSV file."""
        filepath = self.config.get("filepath")
        if not filepath:
            raise ValueError("filepath required for InputCSV")
        
        df = pd.read_csv(filepath)
        return {
            "data": df.to_dict(orient="records"),
            "columns": df.columns.tolist(),
            "rows": len(df)
        }


class InputDatabase(Node):
    """Query data from database."""
    
    def execute(self, input_data: Dict[str, Any], context: Dict) -> Dict:
        """Execute database query."""
        query = self.config.get("query")
        if not query:
            raise ValueError("query required for InputDatabase")
        
        # Use SQLAlchemy for database connection
        db_url = context.get("database_url")
        from sqlalchemy import create_engine
        engine = create_engine(db_url)
        
        df = pd.read_sql_query(query, engine)
        return {
            "data": df.to_dict(orient="records"),
            "columns": df.columns.tolist(),
            "rows": len(df)
        }


class CleanData(Node):
    """Clean and preprocess data."""
    
    def execute(self, input_data: Dict[str, Any], context: Dict) -> Dict:
        """Clean data: remove duplicates, handle missing values."""
        data = input_data.get("data", [])
        df = pd.DataFrame(data)
        
        # Remove duplicates
        df = df.drop_duplicates()
        
        # Handle missing values
        fill_method = self.config.get("fill_method", "drop")
        if fill_method == "drop":
            df = df.dropna()
        elif fill_method == "mean":
            df = df.fillna(df.mean())
        elif fill_method == "ffill":
            df = df.fillna(method="ffill")
        
        return {
            "data": df.to_dict(orient="records"),
            "columns": df.columns.tolist(),
            "rows": len(df)
        }


class TransformData(Node):
    """Transform data: rename columns, calculate new fields."""
    
    def execute(self, input_data: Dict[str, Any], context: Dict) -> Dict:
        """Transform data using mappings and calculations."""
        data = input_data.get("data", [])
        df = pd.DataFrame(data)
        
        # Rename columns
        rename_map = self.config.get("rename_columns", {})
        if rename_map:
            df = df.rename(columns=rename_map)
        
        # Add calculated columns
        for calc in self.config.get("calculations", []):
            col_name = calc["name"]
            formula = calc["formula"]
            # Simple eval - use with caution
            df[col_name] = df.eval(formula)
        
        return {
            "data": df.to_dict(orient="records"),
            "columns": df.columns.tolist(),
            "rows": len(df)
        }


class AIEnrich(Node):
    """Enrich data using OpenAI."""
    
    def execute(self, input_data: Dict[str, Any], context: Dict) -> Dict:
        """Use OpenAI to enrich or analyze data."""
        data = input_data.get("data", [])
        api_key = context.get("openai_api_key")
        
        if not api_key:
            raise ValueError("openai_api_key required in context")
        
        openai.api_key = api_key
        prompt_template = self.config.get("prompt_template")
        output_field = self.config.get("output_field", "enriched")
        
        enriched_data = []
        for item in data:
            # Format prompt with data
            prompt = prompt_template.format(**item)
            
            try:
                response = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.3,
                    max_tokens=200
                )
                item[output_field] = response.choices[0].message.content.strip()
            except Exception as e:
                item[output_field] = f"Error: {str(e)}"
            
            enriched_data.append(item)
        
        return {
            "data": enriched_data,
            "rows": len(enriched_data)
        }


class FilterRows(Node):
    """Filter rows based on conditions."""
    
    def execute(self, input_data: Dict[str, Any], context: Dict) -> Dict:
        """Filter data based on configured conditions."""
        data = input_data.get("data", [])
        df = pd.DataFrame(data)
        
        # Apply filters
        for filter_rule in self.config.get("filters", []):
            column = filter_rule["column"]
            operator = filter_rule["operator"]
            value = filter_rule["value"]
            
            if operator == "==":
                df = df[df[column] == value]
            elif operator == ">":
                df = df[df[column] > value]
            elif operator == "<":
                df = df[df[column] < value]
            elif operator == "contains":
                df = df[df[column].astype(str).str.contains(value)]
            elif operator == "in":
                df = df[df[column].isin(value)]
        
        return {
            "data": df.to_dict(orient="records"),
            "columns": df.columns.tolist(),
            "rows": len(df)
        }


class OutputCSV(Node):
    """Export data to CSV file."""
    
    def execute(self, input_data: Dict[str, Any], context: Dict) -> Dict:
        """Export data to CSV."""
        data = input_data.get("data", [])
        filepath = self.config.get("filepath")
        
        if not filepath:
            raise ValueError("filepath required for OutputCSV")
        
        df = pd.DataFrame(data)
        df.to_csv(filepath, index=False)
        
        return {
            "status": "success",
            "filepath": filepath,
            "rows_written": len(df)
        }


class OutputAPI(Node):
    """Send data to external API via webhook."""
    
    def execute(self, input_data: Dict[str, Any], context: Dict) -> Dict:
        """POST data to webhook URL."""
        import requests
        
        data = input_data.get("data", [])
        url = self.config.get("webhook_url")
        
        if not url:
            raise ValueError("webhook_url required for OutputAPI")
        
        payload = {
            "data": data,
            "timestamp": pd.Timestamp.now().isoformat()
        }
        
        response = requests.post(url, json=payload)
        
        return {
            "status": "success" if response.status_code < 400 else "failed",
            "response_code": response.status_code,
            "rows_sent": len(data)
        }


def get_node_class(node_type: str) -> type:
    """Get node class by type name."""
    nodes = {
        "InputCSV": InputCSV,
        "InputDatabase": InputDatabase,
        "CleanData": CleanData,
        "TransformData": TransformData,
        "AIEnrich": AIEnrich,
        "FilterRows": FilterRows,
        "OutputCSV": OutputCSV,
        "OutputAPI": OutputAPI
    }
    
    if node_type not in nodes:
        raise ValueError(f"Unknown node type: {node_type}")
    
    return nodes[node_type]
