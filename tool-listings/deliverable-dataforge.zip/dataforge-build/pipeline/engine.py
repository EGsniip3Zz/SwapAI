"""
DataForge Pipeline Execution Engine

Processes connected nodes in order and manages data flow between them.
"""

import json
from typing import Dict, Any, List, Optional
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class PipelineEngine:
    """Executes data pipelines with connected nodes."""
    
    def __init__(self):
        """Initialize the pipeline engine."""
        self.execution_id = None
        self.start_time = None
        self.nodes_executed = []
        self.errors = []
    
    def validate_pipeline(self, pipeline_config: Dict[str, Any]) -> tuple:
        """
        Validate pipeline configuration.
        
        Args:
            pipeline_config: Pipeline configuration dictionary
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if "nodes" not in pipeline_config or not pipeline_config["nodes"]:
            return False, "Pipeline has no nodes"
        
        # Check all connections reference valid nodes
        nodes = {n["id"]: n for n in pipeline_config["nodes"]}
        
        for connection in pipeline_config.get("connections", []):
            if connection["from"] not in nodes or connection["to"] not in nodes:
                return False, f"Invalid connection: {connection}"
        
        # Check for circular dependencies
        if self._has_circular_dependency(pipeline_config):
            return False, "Pipeline has circular dependencies"
        
        return True, ""
    
    def _has_circular_dependency(self, pipeline_config: Dict[str, Any]) -> bool:
        """Check if pipeline has circular dependencies."""
        nodes = {n["id"]: n for n in pipeline_config["nodes"]}
        visited = set()
        rec_stack = set()
        
        def has_cycle(node_id):
            visited.add(node_id)
            rec_stack.add(node_id)
            
            for connection in pipeline_config.get("connections", []):
                if connection["from"] == node_id:
                    next_id = connection["to"]
                    if next_id not in visited:
                        if has_cycle(next_id):
                            return True
                    elif next_id in rec_stack:
                        return True
            
            rec_stack.remove(node_id)
            return False
        
        for node_id in nodes:
            if node_id not in visited:
                if has_cycle(node_id):
                    return True
        
        return False
    
    def get_execution_order(self, pipeline_config: Dict[str, Any]) -> List[str]:
        """
        Get topological sort order for node execution.
        
        Args:
            pipeline_config: Pipeline configuration
            
        Returns:
            List of node IDs in execution order
        """
        nodes = {n["id"]: n for n in pipeline_config["nodes"]}
        in_degree = {node_id: 0 for node_id in nodes}
        
        # Calculate in-degrees
        for connection in pipeline_config.get("connections", []):
            in_degree[connection["to"]] += 1
        
        # Find all nodes with no incoming edges
        queue = [node_id for node_id, degree in in_degree.items() if degree == 0]
        result = []
        
        while queue:
            node_id = queue.pop(0)
            result.append(node_id)
            
            # Remove edges from this node
            for connection in pipeline_config.get("connections", []):
                if connection["from"] == node_id:
                    to_node = connection["to"]
                    in_degree[to_node] -= 1
                    if in_degree[to_node] == 0:
                        queue.append(to_node)
        
        return result
    
    def execute(self, pipeline_config: Dict[str, Any], context: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Execute a complete pipeline.
        
        Args:
            pipeline_config: Pipeline configuration dictionary
            context: Execution context and variables
            
        Returns:
            Execution result with outputs and metadata
        """
        # Validate pipeline
        is_valid, error_msg = self.validate_pipeline(pipeline_config)
        if not is_valid:
            raise ValueError(f"Invalid pipeline: {error_msg}")
        
        self.execution_id = pipeline_config.get("id", "unknown")
        self.start_time = datetime.now()
        self.nodes_executed = []
        self.errors = []
        
        context = context or {}
        node_outputs = {}
        
        try:
            # Get execution order
            order = self.get_execution_order(pipeline_config)
            nodes = {n["id"]: n for n in pipeline_config["nodes"]}
            
            # Execute each node
            for node_id in order:
                try:
                    node_config = nodes[node_id]
                    logger.info(f"Executing node: {node_id}")
                    
                    # Get input data from previous nodes
                    node_input = self._get_node_input(
                        node_id, pipeline_config, node_outputs
                    )
                    
                    # Import and execute node
                    from pipeline.nodes import get_node_class
                    node_class = get_node_class(node_config["type"])
                    node = node_class(node_config)
                    
                    output = node.execute(node_input, context)
                    node_outputs[node_id] = output
                    self.nodes_executed.append(node_id)
                
                except Exception as e:
                    error = f"Node {node_id} failed: {str(e)}"
                    logger.error(error)
                    self.errors.append(error)
                    
                    # Continue or stop based on error handling
                    if nodes[node_id].get("stop_on_error", True):
                        raise
            
            return {
                "status": "success",
                "execution_id": self.execution_id,
                "duration": (datetime.now() - self.start_time).total_seconds(),
                "nodes_executed": self.nodes_executed,
                "outputs": node_outputs,
                "errors": self.errors
            }
        
        except Exception as e:
            return {
                "status": "failed",
                "execution_id": self.execution_id,
                "duration": (datetime.now() - self.start_time).total_seconds(),
                "nodes_executed": self.nodes_executed,
                "error": str(e),
                "errors": self.errors
            }
    
    def _get_node_input(self, node_id: str, pipeline_config: Dict, outputs: Dict) -> Dict:
        """Get input data for a node from connected nodes."""
        node_input = {}
        
        for connection in pipeline_config.get("connections", []):
            if connection["to"] == node_id:
                from_node_id = connection["from"]
                from_port = connection.get("from_port", "output")
                to_port = connection.get("to_port", "input")
                
                if from_node_id in outputs:
                    output_data = outputs[from_node_id]
                    if isinstance(output_data, dict):
                        node_input[to_port] = output_data.get(from_port)
                    else:
                        node_input[to_port] = output_data
        
        return node_input
