# DataForge - No-Code AI Data Pipeline Builder

Build powerful data pipelines without writing code. Connect nodes to clean, transform, enrich, and export data automatically.

## Features

- **Visual Pipeline Builder**: Drag-and-drop interface for pipeline creation
- **Pre-built Nodes**: Input, transformation, AI enrichment, filtering, output nodes
- **Data Source Support**: CSV, databases, APIs, JSON
- **AI Enrichment**: Use OpenAI to enrich and analyze data
- **Real-time Execution**: Run pipelines on-demand or schedule them
- **Version Control**: Track pipeline changes and rollback

## System Requirements

- Python 3.9+
- 2GB RAM minimum
- Modern web browser
- OpenAI API key (for AI enrichment)
- Redis (for async job processing)

## Installation

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. Setup database:
   ```bash
   python setup_db.py
   ```

3. Configure environment:
   ```bash
   cp .env.example .env
   # Edit .env with your settings
   ```

## Usage

### Start Server
```bash
python -m uvicorn api.server:app --reload
```

### Access UI
Open http://localhost:8000/builder in your browser

### Create Pipeline
1. Click "New Pipeline"
2. Drag nodes from sidebar to canvas
3. Connect nodes with their input/output ports
4. Configure each node
5. Save and run

## Node Types

- **InputCSV**: Load data from CSV file
- **InputDatabase**: Query from SQL database
- **CleanData**: Remove duplicates, handle missing values
- **TransformData**: Rename columns, calculate new fields
- **AIEnrich**: Use GPT to generate or analyze data
- **FilterRows**: Filter based on conditions
- **OutputCSV**: Export to CSV file
- **OutputAPI**: POST to webhook or API

## Configuration

Edit .env:
- `OPENAI_API_KEY`: OpenAI API key for enrichment
- `DATABASE_URL`: PostgreSQL connection string
- `REDIS_URL`: Redis connection for job queue

## Example Pipeline

Load customer CSV → Clean data → Enrich with AI → Filter → Export

## License

Commercial License
