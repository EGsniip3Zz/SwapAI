"""
ReceiptBrain - Flask API Server
REST API for receipt scanning and data extraction.
"""

import os
import json
import time
import logging
from pathlib import Path
from tempfile import NamedTemporaryFile

from flask import Flask, request, jsonify, render_template
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from scan import ReceiptScanner

load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__, template_folder='../templates')
app.config['MAX_CONTENT_LENGTH'] = int(os.getenv('MAX_FILE_SIZE', 10)) * 1024 * 1024
app.config['UPLOAD_FOLDER'] = os.getenv('UPLOAD_FOLDER', './uploads')

Path(app.config['UPLOAD_FOLDER']).mkdir(parents=True, exist_ok=True)

scanner = ReceiptScanner()

ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'pdf', 'bmp'}


def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/')
def index():
    """Serve main interface"""
    return render_template('index.html')


@app.route('/scan', methods=['POST'])
def scan_receipt():
    """Scan a receipt image"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type'}), 400
        
        with NamedTemporaryFile(delete=False, suffix=os.path.splitext(file.filename)[1]) as tmp:
            file.save(tmp.name)
            temp_path = tmp.name
        
        start_time = time.time()
        result = scanner.scan(temp_path)
        processing_time = (time.time() - start_time) * 1000
        
        result['processing_time_ms'] = int(processing_time)
        
        os.unlink(temp_path)
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"Scan error: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/health')
def health():
    """Health check"""
    return jsonify({'status': 'healthy'})


if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
