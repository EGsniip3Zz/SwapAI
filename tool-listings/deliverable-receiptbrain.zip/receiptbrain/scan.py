"""
ReceiptBrain - Receipt Scanning Module
OCR and AI-powered receipt data extraction.
"""

import os
import logging
from pathlib import Path
from io import BytesIO

import pytesseract
import openai
from PIL import Image
import numpy as np
import cv2
from pdf2image import convert_from_path
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

TESSERACT_PATH = os.getenv('TESSERACT_PATH', '/usr/bin/tesseract')
openai.api_key = os.getenv('OPENAI_API_KEY')

# Configure Tesseract
if os.path.exists(TESSERACT_PATH):
    pytesseract.pytesseract.pytesseract_cmd = TESSERACT_PATH


class ReceiptScanner:
    """Scan and extract data from receipt images"""
    
    def __init__(self):
        self.min_confidence = 0.70
    
    def load_image(self, file_path):
        """Load image from file"""
        img = Image.open(file_path)
        return np.array(img)
    
    def load_pdf_page(self, pdf_path, page_num=0):
        """Convert PDF page to image"""
        try:
            images = convert_from_path(pdf_path, first_page=page_num+1, last_page=page_num+1)
            return np.array(images[0])
        except Exception as e:
            logger.error(f"PDF conversion error: {e}")
            return None
    
    def preprocess_image(self, image):
        """Preprocess image for better OCR"""
        # Convert to grayscale
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        else:
            gray = image
        
        # Detect and correct rotation
        gray = self._correct_rotation(gray)
        
        # Enhance contrast
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(gray)
        
        # Denoise
        denoised = cv2.fastNlMeansDenoising(enhanced, h=10)
        
        return denoised
    
    def _correct_rotation(self, gray):
        """Auto-correct image rotation"""
        try:
            coords = np.column_stack(np.where(gray > 127))
            if len(coords) < 10:
                return gray
            
            angle = cv2.minAreaRect(cv2.convexHull(coords))[2]
            if angle < -45:
                angle = 90 + angle
            
            if abs(angle) > 1:
                h, w = gray.shape
                center = (w // 2, h // 2)
                M = cv2.getRotationMatrix2D(center, angle, 1.0)
                rotated = cv2.warpAffine(gray, M, (w, h))
                return rotated
        except:
            pass
        
        return gray
    
    def extract_text(self, image):
        """Extract text from image using Tesseract"""
        try:
            text = pytesseract.image_to_string(image)
            logger.info(f"Extracted {len(text)} characters via OCR")
            return text
        except Exception as e:
            logger.error(f"OCR error: {e}")
            raise
    
    def parse_receipt_data(self, text):
        """Parse receipt text into structured data using OpenAI"""
        try:
            prompt = f"""
            Extract receipt information from the following text. Return valid JSON only.
            
            Text:
            {text}
            
            Return JSON with these fields:
            {{
                "merchant": "store name",
                "date": "YYYY-MM-DD",
                "time": "HH:MM",
                "total": total_amount_float,
                "subtotal": subtotal_float,
                "tax": tax_float,
                "items": [
                    {{"description": "item name", "quantity": 1, "unit_price": 0.00, "total_price": 0.00}}
                ],
                "payment_method": "card type or cash",
                "confidence_score": 0.85
            }}
            
            Use null for unknown fields. Be strict with JSON format.
            """
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=1000
            )
            
            response_text = response.choices[0].message.content
            
            # Extract JSON from response
            import json
            import re
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                data = json.loads(json_match.group())
                logger.info(f"Parsed receipt data: {data.get('merchant')} - ${data.get('total')}")
                return data
            
            return None
        except Exception as e:
            logger.error(f"Parsing error: {e}")
            return None
    
    def scan(self, file_path):
        """Complete scan pipeline"""
        try:
            # Detect file type
            file_path = str(file_path)
            
            if file_path.lower().endswith('.pdf'):
                image = self.load_pdf_page(file_path)
            else:
                image = self.load_image(file_path)
            
            if image is None:
                return {'error': 'Failed to load image'}
            
            # Preprocess
            processed = self.preprocess_image(image)
            
            # Extract text
            text = self.extract_text(processed)
            
            if not text.strip():
                return {'error': 'No text found in image'}
            
            # Parse with AI
            receipt_data = self.parse_receipt_data(text)
            
            if not receipt_data:
                return {'error': 'Failed to parse receipt data'}
            
            receipt_data['success'] = True
            receipt_data['raw_text'] = text[:500]  # Include sample of OCR
            
            return receipt_data
        
        except Exception as e:
            logger.error(f"Scan error: {e}")
            return {'error': str(e), 'success': False}


if __name__ == '__main__':
    scanner = ReceiptScanner()
    
    # Test with sample image
    test_image = 'sample_receipt.jpg'
    if os.path.exists(test_image):
        result = scanner.scan(test_image)
        import json
        print(json.dumps(result, indent=2))
