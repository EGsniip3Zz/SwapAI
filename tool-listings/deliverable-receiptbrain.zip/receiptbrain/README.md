# ReceiptBrain - AI Receipt Scanner

**Enterprise-grade receipt scanning and data extraction using OCR and AI. Convert physical and digital receipts into structured data in seconds.**

## Overview

ReceiptBrain automatically extracts key information from receipt images including merchant name, total amount, tax, items, and dates. Uses Tesseract OCR combined with OpenAI's vision capabilities for 95%+ accuracy.

**Pricing:** $149 one-time license
**Licensing Model:** Commercial use, unlimited scans
**Processing:** Real-time via REST API

## Requirements

- Python 3.8+
- Tesseract OCR engine
- OpenAI API key
- Flask 2.3+
- 2GB RAM minimum
- 500MB disk space

## Installation & Setup

### 1. Install Tesseract OCR

**Ubuntu/Debian:**
```bash
sudo apt-get install tesseract-ocr
```

**macOS:**
```bash
brew install tesseract
```

**Windows:**
Download installer from: https://github.com/UB-Mannheim/tesseract/wiki

### 2. Install Python Dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure Environment

```bash
cp .env.example .env
```

Update variables:
```
OPENAI_API_KEY=sk-your-key
TESSERACT_PATH=/usr/bin/tesseract
PORT=5000
MAX_FILE_SIZE=10
```

### 4. Start the Server

```bash
python api/server.py
```

Access at: `http://localhost:5000`

## API Endpoints

### Scan Receipt
```
POST /scan
Content-Type: multipart/form-data

Parameters:
- file: Receipt image (JPG, PNG, PDF)
- store_name: Optional store name

Response:
{
    "success": true,
    "merchant": "CVS Pharmacy",
    "date": "2025-02-15",
    "total": 24.99,
    "subtotal": 21.99,
    "tax": 3.00,
    "items": [
        {"description": "Advil", "quantity": 1, "price": 9.99},
        {"description": "Water Bottle", "quantity": 2, "price": 5.99}
    ],
    "payment_method": "Credit Card",
    "confidence_score": 0.94,
    "processing_time_ms": 1850
}
```

### Batch Processing
```
POST /batch-scan
Content-Type: application/json

{
    "files": ["receipt1.jpg", "receipt2.jpg"],
    "extract_items": true
}

Response:
{
    "results": [ { receipt data } ],
    "total_processed": 2,
    "success_count": 2,
    "processing_time_seconds": 4.2
}
```

## Web Interface

1. Navigate to `http://localhost:5000`
2. Upload receipt image (JPG/PNG/PDF)
3. Click "Scan Receipt"
4. View extracted data
5. Download as JSON or CSV

## Data Extraction Details

### Extracted Fields

| Field | Type | Example |
|-------|------|---------|
| merchant | string | "Whole Foods Market" |
| date | ISO date | "2025-02-15" |
| time | time | "14:35" |
| total | float | 124.56 |
| subtotal | float | 118.32 |
| tax | float | 6.24 |
| items | array | [{ item objects }] |
| payment_method | string | "Visa" |
| confidence_score | float | 0.95 |

### Item Fields

```json
{
    "description": "Product name",
    "quantity": 1,
    "unit_price": 9.99,
    "total_price": 9.99,
    "category": "Health & Beauty"
}
```

## Receipt Format Support

| Format | Type | Notes |
|--------|------|-------|
| JPEG | Image | Recommended, best compatibility |
| PNG | Image | Good for digital receipts |
| PDF | Document | Converts to image internally |
| BMP | Image | Supported |

**File size limit:** 10MB
**Image resolution:** 150 DPI minimum

## Usage Examples

### Web Upload

Visit `http://localhost:5000` and use the dark-themed upload interface.

### Python Client

```python
import requests

API_URL = 'http://localhost:5000'

# Single receipt
with open('receipt.jpg', 'rb') as f:
    response = requests.post(
        f'{API_URL}/scan',
        files={'file': f}
    )

data = response.json()
print(f"Merchant: {data['merchant']}")
print(f"Total: ${data['total']:.2f}")
print(f"Items: {len(data['items'])}")
```

### Batch Processing

```python
import os
import requests

receipt_files = [f for f in os.listdir('./receipts') if f.endswith('.jpg')]

with open('receipt.jpg', 'rb') as f:
    files = {'files': [open(rf, 'rb') for rf in receipt_files]}
    response = requests.post(
        f'{API_URL}/batch-scan',
        files=files
    )

results = response.json()['results']
for receipt in results:
    print(f"{receipt['merchant']}: ${receipt['total']:.2f}")
```

### cURL Example

```bash
curl -X POST http://localhost:5000/scan \
  -F "file=@receipt.jpg" \
  -o result.json
```

## Processing Pipeline

1. **File Validation**: Check format, size, and resolution
2. **PDF Conversion**: If PDF, convert to image
3. **Image Preprocessing**: Rotation detection, enhancement
4. **OCR Extraction**: Tesseract text recognition
5. **AI Enhancement**: OpenAI vision for accuracy
6. **Data Parsing**: Structured extraction of key fields
7. **Validation**: Consistency checks on amounts

## Accuracy Optimization

### Tips for Better Results

- **Clear images**: Avoid shadows, glare, reflections
- **Full view**: Capture entire receipt
- **Straight angles**: Scan receipt straight-on
- **Good lighting**: Adequate brightness
- **High contrast**: Dark text on light background

### Confidence Scores

- 0.90+: Excellent - Direct use recommended
- 0.80-0.89: Good - Minor manual review recommended
- 0.70-0.79: Fair - Review before use
- <0.70: Poor - Manual entry recommended

## Deployment

### Production Deployment

```bash
gunicorn --workers 2 --bind 0.0.0.0:5000 api.server:app
```

### Docker Deployment

```dockerfile
FROM ubuntu:22.04
RUN apt-get update && apt-get install -y python3.9 tesseract-ocr
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "api/server.py"]
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Tesseract not found" | Install OCR, set TESSERACT_PATH |
| "Invalid API key" | Check OPENAI_API_KEY in .env |
| "Low confidence score" | Use clearer image, better lighting |
| "Text not extracted" | Try rotating image, check DPI |

## Compliance & Privacy

- No data retained after processing (by default)
- GDPR compliant architecture
- No external storage unless configured
- All processing can run on-premises
- API key authentication required

## License & Support

License: Commercial (one-time $149)
Support: Email support
Updates: Included for 1 year
Custom OCR: Available for enterprise customers

Email: support@receiptbrain.io
Docs: https://docs.receiptbrain.io

## Version History

- v1.1.0 - Batch processing support (Feb 2025)
- v1.0.0 - Initial release
