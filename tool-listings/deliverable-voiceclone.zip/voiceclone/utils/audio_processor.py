"""
VoiceClone Audio Processing Utilities
Handles audio format conversion, noise reduction, and normalization.
"""

import os
import logging
from pathlib import Path

import numpy as np
import librosa
import soundfile as sf
from scipy import signal
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

SAMPLE_RATE = int(os.getenv('SAMPLE_RATE', 22050))
NORMALIZE_VOLUME = os.getenv('NORMALIZE_VOLUME', 'true').lower() == 'true'
REMOVE_SILENCE = os.getenv('REMOVE_SILENCE', 'true').lower() == 'true'
NOISE_REDUCTION = os.getenv('NOISE_REDUCTION', 'true').lower() == 'true'


class AudioProcessor:
    """Process and enhance audio for voice cloning"""
    
    def __init__(self, sample_rate=SAMPLE_RATE):
        self.sample_rate = sample_rate
    
    def load_audio(self, file_path):
        """Load audio file in any format"""
        try:
            y, sr = librosa.load(file_path, sr=None)
            logger.info(f"Loaded audio: {file_path} (sr={sr})")
            return y, sr
        except Exception as e:
            logger.error(f"Error loading audio: {e}")
            raise
    
    def resample(self, y, sr_original, sr_target=None):
        """Resample audio to target sample rate"""
        if sr_target is None:
            sr_target = self.sample_rate
        
        if sr_original == sr_target:
            return y
        
        y_resampled = librosa.resample(y, orig_sr=sr_original, target_sr=sr_target)
        logger.info(f"Resampled from {sr_original} to {sr_target}")
        return y_resampled
    
    def trim_silence(self, y, sr, top_db=40):
        """Remove silence from beginning and end"""
        try:
            y_trimmed, _ = librosa.effects.trim(y, top_db=top_db)
            logger.info(f"Trimmed silence: {len(y)} -> {len(y_trimmed)} samples")
            return y_trimmed
        except Exception as e:
            logger.error(f"Error trimming silence: {e}")
            return y
    
    def reduce_noise(self, y, sr):
        """Simple noise reduction using spectral gating"""
        try:
            # Compute spectrogram
            D = librosa.stft(y)
            magnitude = np.abs(D)
            
            # Estimate noise from quiet parts
            noise_profile = np.percentile(magnitude, 20, axis=1, keepdims=True)
            
            # Apply spectral gating
            mask = magnitude > 2 * noise_profile
            D_filtered = D * mask
            
            # Reconstruct audio
            y_reduced = librosa.istft(D_filtered)
            logger.info("Applied noise reduction")
            return y_reduced
        except Exception as e:
            logger.error(f"Error reducing noise: {e}")
            return y
    
    def normalize_volume(self, y, target_loudness=-20.0):
        """Normalize audio volume to target loudness (dBFS)"""
        try:
            # Calculate current loudness
            S = librosa.feature.melspectrogram(y=y, sr=self.sample_rate)
            loudness = np.mean(librosa.power_to_db(S))
            
            # Calculate gain needed
            gain = target_loudness - loudness
            
            # Apply gain
            y_normalized = y * (10 ** (gain / 20))
            
            # Clip to prevent distortion
            y_normalized = np.clip(y_normalized, -1.0, 1.0)
            
            logger.info(f"Normalized volume: {loudness:.1f}dB -> {target_loudness:.1f}dB")
            return y_normalized
        except Exception as e:
            logger.error(f"Error normalizing volume: {e}")
            return y
    
    def enhance_speech(self, y, sr):
        """Enhance speech clarity using high-pass filter"""
        try:
            # High-pass filter to remove low-frequency rumble
            sos = signal.butter(4, 100, 'hp', fs=sr, output='sos')
            y_filtered = signal.sosfilt(sos, y)
            
            logger.info("Applied speech enhancement")
            return y_filtered
        except Exception as e:
            logger.error(f"Error enhancing speech: {e}")
            return y
    
    def process_for_cloning(self, file_path, output_path=None):
        """Complete processing pipeline for voice cloning"""
        try:
            # Load
            y, sr = self.load_audio(file_path)
            
            # Resample
            y = self.resample(y, sr, self.sample_rate)
            
            # Trim silence
            if REMOVE_SILENCE:
                y = self.trim_silence(y)
            
            # Reduce noise
            if NOISE_REDUCTION:
                y = self.reduce_noise(y, self.sample_rate)
            
            # Enhance speech
            y = self.enhance_speech(y, self.sample_rate)
            
            # Normalize
            if NORMALIZE_VOLUME:
                y = self.normalize_volume(y)
            
            # Save if output path provided
            if output_path:
                sf.write(output_path, y, self.sample_rate)
                logger.info(f"Saved processed audio to {output_path}")
            
            return y, self.sample_rate
        except Exception as e:
            logger.error(f"Error in processing pipeline: {e}")
            raise
    
    def get_duration(self, y, sr):
        """Get audio duration in seconds"""
        return len(y) / sr
    
    def validate_audio(self, y, sr, min_duration=3.0, max_duration=30.0):
        """Validate audio meets requirements"""
        duration = self.get_duration(y, sr)
        
        if duration < min_duration:
            raise ValueError(f"Audio too short: {duration:.1f}s (minimum {min_duration}s)")
        
        if duration > max_duration:
            raise ValueError(f"Audio too long: {duration:.1f}s (maximum {max_duration}s)")
        
        if np.max(np.abs(y)) < 0.01:
            raise ValueError("Audio level too low")
        
        if np.max(np.abs(y)) > 1.0:
            logger.warning("Audio clipping detected, normalizing...")
            y = y / np.max(np.abs(y))
        
        return True


if __name__ == '__main__':
    # Test audio processing
    processor = AudioProcessor()
    
    test_file = 'test_audio.wav'
    if os.path.exists(test_file):
        y, sr = processor.load_audio(test_file)
        y_processed, sr = processor.process_for_cloning(test_file)
        print(f"Processed successfully: {len(y_processed)} samples")
