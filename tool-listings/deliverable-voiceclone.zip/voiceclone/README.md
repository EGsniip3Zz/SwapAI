# VoiceClone Studio - AI Voice Cloning

**Enterprise voice cloning technology with natural-sounding synthesis and speaker adaptation. Create human-quality voiceovers from any voice sample.**

## Overview

VoiceClone Studio uses cutting-edge neural TTS (Text-to-Speech) technology to clone voices from short audio samples. Perfect for audiobooks, IVR systems, marketing videos, and accessibility applications.

**Pricing:** $4,999 one-time license
**Licensing Model:** Commercial use, unlimited clones
**Features:** 40+ languages, real-time synthesis, GPU acceleration

## Requirements

- Python 3.9+
- CUDA 11.0+ (for GPU acceleration, optional but recommended)
- 8GB+ RAM
- 10GB+ disk space
- 2+ GB VRAM for GPU mode

## Installation & Setup

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

For NVIDIA GPU support:
```bash
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
```

### 2. Environment Configuration

```bash
cp .env.example .env
```

Edit `.env`:
```
MODEL_DIR=./models
MAX_AUDIO_LENGTH=30
OUTPUT_FORMAT=wav
USE_GPU=true
SAMPLE_RATE=22050
```

### 3. Download Models

```bash
python download_models.py
```

This downloads pre-trained Coqui TTS models (~2GB).

### 4. Start the API Server

```bash
python api/server.py
```

Server runs on `http://localhost:8000`

## API Endpoints

### Clone a Voice
```
POST /clone
Content-Type: multipart/form-data

Parameters:
- voice_sample: Audio file (WAV/MP3, 3-30 seconds)
- speaker_name: Name for cloned voice
- language: ISO 639-1 code (en, es, fr, de, etc.)

Response:
{
    "speaker_id": "spk_xyz123",
    "speaker_name": "My Custom Voice",
    "status": "ready",
    "language": "en",
    "quality": "high",
    "model_used": "glow-tts"
}
```

### Synthesize Text
```
POST /synthesize
Content-Type: application/json

{
    "text": "Hello, this is a cloned voice speaking.",
    "speaker_id": "spk_xyz123",
    "speed": 1.0,
    "pitch": 1.0,
    "format": "wav"
}

Response:
{
    "audio_url": "https://your-cdn.com/audio_xyz.wav",
    "duration_seconds": 2.5,
    "sample_rate": 22050,
    "format": "wav"
}
```

### List Available Voices
```
GET /voices

Response:
{
    "custom_voices": [
        {
            "speaker_id": "spk_001",
            "name": "Voice One",
            "language": "en",
            "created_at": "2025-02-15T10:30:00Z"
        }
    ],
    "preset_voices": ["default_male", "default_female"],
    "total": 15
}
```

### Delete Voice
```
DELETE /voices/{speaker_id}

Response:
{
    "status": "deleted",
    "speaker_id": "spk_xyz123"
}
```

## Audio Formats Supported

| Format | Codec | Quality |
|--------|-------|---------|
| WAV | PCM | Full (lossless) |
| MP3 | MP3 | 192kbps+ recommended |
| OGG | Vorbis | 128kbps+ |
| M4A | AAC | 128kbps+ |

## Python Client Example

```python
import requests
import time

API_URL = 'http://localhost:8000'

# 1. Clone a voice
with open('speaker_sample.wav', 'rb') as f:
    response = requests.post(
        f'{API_URL}/clone',
        files={'voice_sample': f},
        data={
            'speaker_name': 'John Doe',
            'language': 'en'
        }
    )
    
speaker_data = response.json()
speaker_id = speaker_data['speaker_id']

# 2. Synthesize speech
text = "Welcome to VoiceClone Studio. This is a natural-sounding voice clone."

synthesis_response = requests.post(
    f'{API_URL}/synthesize',
    json={
        'text': text,
        'speaker_id': speaker_id,
        'speed': 1.0,
        'pitch': 1.0,
        'format': 'wav'
    }
)

audio_data = synthesis_response.json()
print(f"Audio generated: {audio_data['audio_url']}")
print(f"Duration: {audio_data['duration_seconds']}s")
```

## Audio Processing Pipeline

The `utils/audio_processor.py` handles:

1. **Format Conversion**: Converts MP3, OGG, M4A to WAV
2. **Resampling**: Normalizes to 22050 Hz
3. **Noise Reduction**: Removes background noise
4. **Volume Normalization**: Optimizes loudness
5. **Silence Trimming**: Removes leading/trailing silence
6. **Speech Enhancement**: Clarity improvement

## Performance Tuning

### GPU Acceleration

Enable GPU for 5-10x faster synthesis:

```
USE_GPU=true
DEVICE=cuda
```

Check GPU status:
```python
import torch
print(torch.cuda.is_available())
print(torch.cuda.get_device_name(0))
```

### Batch Processing

For high-volume synthesis:

```python
texts = [
    "First sentence to synthesize.",
    "Second sentence to synthesize.",
    "Third sentence to synthesize."
]

batch_response = requests.post(
    f'{API_URL}/batch-synthesize',
    json={
        'texts': texts,
        'speaker_id': speaker_id
    }
)
```

## Language Support

| Language | Code | Voices | Quality |
|----------|------|--------|---------|
| English | en | 4 | Excellent |
| Spanish | es | 3 | Excellent |
| French | fr | 3 | Excellent |
| German | de | 3 | Good |
| Italian | it | 2 | Good |
| Portuguese | pt | 2 | Good |

## Limitations & Considerations

- **Maximum input text**: 5000 characters per synthesis
- **Maximum sample length**: 30 seconds
- **Minimum sample length**: 3 seconds
- **Real-time synthesis**: ~1-2 seconds for typical sentences
- **Voice quality improves with**: Longer/cleaner sample audio

## Deployment

### Docker Deployment

```dockerfile
FROM nvidia/cuda:11.8.0-runtime-ubuntu22.04
WORKDIR /app
RUN apt-get update && apt-get install -y python3.9 ffmpeg
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "api/server.py"]
```

### Docker Compose

```yaml
version: '3.8'
services:
  voiceclone:
    image: voiceclone-studio:latest
    ports:
      - "8000:8000"
    environment:
      USE_GPU: "true"
      CUDA_VISIBLE_DEVICES: "0"
    volumes:
      - ./models:/app/models
      - ./output:/app/output
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| CUDA out of memory | Reduce batch size, lower quality |
| Poor voice quality | Use longer/clearer voice sample |
| Synthesis too slow | Enable GPU, reduce text length |
| Models not downloading | Check internet, increase timeout |

## License & Support

License: Commercial (one-time $4,999)
Support: Priority technical support, model updates
Custom Models: Available at enterprise tier
SLA: 99.5% uptime guarantee

Email: support@voiceclone.studio
Docs: https://docs.voiceclone.studio

## Version History

- v1.2.0 - Multi-speaker support (Feb 2025)
- v1.1.0 - CUDA 11.8 support
- v1.0.0 - Initial release
