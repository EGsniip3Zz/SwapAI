"""
VoiceClone Studio - FastAPI Server
REST API for voice cloning and synthesis.
"""

import os
import json
import uuid
import logging
from pathlib import Path
from tempfile import TemporaryDirectory

from fastapi import FastAPI, File, UploadFile, HTTPException, Header
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import numpy as np
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)
logging.basicConfig(level=os.getenv('LOG_LEVEL', 'INFO'))

app = FastAPI(
    title="VoiceClone Studio API",
    description="AI voice cloning and synthesis service",
    version="1.2.0"
)

# Configuration
MODEL_DIR = os.getenv('MODEL_DIR', './models')
OUTPUT_FORMAT = os.getenv('OUTPUT_FORMAT', 'wav')

# Try to import TTS
try:
    from TTS.api import TTS
    from utils.audio_processor import AudioProcessor
    
    # Initialize TTS model (lazy load)
    tts_model = None
    audio_processor = AudioProcessor()
except ImportError:
    logger.warning("TTS library not available - synthesis disabled")
    tts_model = None
    audio_processor = None

# Storage for cloned voices
VOICES_DB = {}


class VoiceCloneRequest(BaseModel):
    """Voice cloning request"""
    speaker_name: str
    language: str = "en"


class SynthesisRequest(BaseModel):
    """Text synthesis request"""
    text: str
    speaker_id: str
    speed: float = 1.0
    pitch: float = 1.0
    format: str = "wav"


@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "tts_available": tts_model is not None,
        "version": "1.2.0"
    }


@app.post("/clone")
async def clone_voice(
    file: UploadFile = File(...),
    speaker_name: str = "Custom Voice",
    language: str = "en"
):
    """Clone a voice from audio sample"""
    
    if not audio_processor:
        raise HTTPException(status_code=503, detail="TTS not available")
    
    try:
        # Save uploaded file
        with TemporaryDirectory() as tmpdir:
            temp_path = os.path.join(tmpdir, file.filename)
            
            content = await file.read()
            with open(temp_path, 'wb') as f:
                f.write(content)
            
            # Process audio
            y, sr = audio_processor.process_for_cloning(temp_path)
            
            # Validate audio
            audio_processor.validate_audio(y, sr)
            
            # Generate speaker ID
            speaker_id = f"spk_{uuid.uuid4().hex[:12]}"
            
            # Store voice info
            VOICES_DB[speaker_id] = {
                "speaker_id": speaker_id,
                "name": speaker_name,
                "language": language,
                "duration": audio_processor.get_duration(y, sr),
                "sample_rate": sr,
                "audio_path": temp_path,
                "created_at": str(np.datetime64('today'))
            }
            
            logger.info(f"Voice cloned: {speaker_id} ({speaker_name})")
            
            return {
                "speaker_id": speaker_id,
                "speaker_name": speaker_name,
                "status": "ready",
                "language": language,
                "quality": "high",
                "model_used": "glow-tts"
            }
    
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Clone error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/synthesize")
async def synthesize(request: SynthesisRequest):
    """Synthesize text with cloned voice"""
    
    if not tts_model:
        raise HTTPException(status_code=503, detail="TTS not available")
    
    if len(request.text) > 5000:
        raise HTTPException(status_code=400, detail="Text too long (max 5000 chars)")
    
    try:
        # Simulate synthesis (in production, would use actual TTS)
        speaker_info = VOICES_DB.get(request.speaker_id)
        if not speaker_info:
            raise HTTPException(status_code=404, detail="Speaker not found")
        
        # Generate audio (placeholder)
        duration = len(request.text) / 100  # Rough estimate
        
        logger.info(f"Synthesized: {len(request.text)} chars, {duration:.1f}s")
        
        return {
            "audio_url": f"https://cdn.example.com/audio_{uuid.uuid4().hex[:8]}.{request.format}",
            "duration_seconds": duration,
            "sample_rate": 22050,
            "format": request.format
        }
    except Exception as e:
        logger.error(f"Synthesis error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/voices")
async def list_voices():
    """List all available voices"""
    return {
        "custom_voices": list(VOICES_DB.values()),
        "preset_voices": ["default_male", "default_female"],
        "total": len(VOICES_DB) + 2
    }


@app.delete("/voices/{speaker_id}")
async def delete_voice(speaker_id: str):
    """Delete a cloned voice"""
    if speaker_id not in VOICES_DB:
        raise HTTPException(status_code=404, detail="Speaker not found")
    
    del VOICES_DB[speaker_id]
    logger.info(f"Deleted voice: {speaker_id}")
    
    return {
        "status": "deleted",
        "speaker_id": speaker_id
    }


if __name__ == '__main__':
    import uvicorn
    port = int(os.getenv('PORT', 8000))
    uvicorn.run(app, host='0.0.0.0', port=port)
