# DreamRender AI - Product Photo Generator

**Professional AI-powered product photography generator that creates stunning product images from text descriptions and specifications.**

## Overview

DreamRender AI uses OpenAI's DALL-E 3 to generate high-quality product photos. Perfect for e-commerce businesses, marketers, and designers who need on-demand product imagery without expensive photoshoots.

**Pricing:** $297 one-time license
**Licensing Model:** Commercial use included

## Requirements

- Python 3.9+
- OpenAI API key (DALL-E 3 access)
- AWS S3 bucket (optional, for image storage)
- 2GB RAM minimum
- 1GB disk space

## Installation & Setup

### 1. Clone and Install Dependencies

```bash
cd dreamrender-ai
pip install -r requirements.txt
```

### 2. Environment Configuration

Create a `.env` file from `.env.example`:

```bash
cp .env.example .env
```

Update the following variables:

```
OPENAI_API_KEY=sk-your-openai-api-key-here
AWS_BUCKET=your-s3-bucket-name (optional)
AWS_REGION=us-east-1 (optional)
PORT=5000
FLASK_ENV=production
```

### 3. First Run

```bash
python app.py
```

The application will start on `http://localhost:5000`

## API Endpoints

### Upload Product Image
- **Endpoint:** `POST /upload`
- **Parameters:** image file, product_name
- **Response:** JSON with image_id, processed_path

### Generate Product Photo
- **Endpoint:** `POST /generate`
- **Parameters:** prompt, style, product_category
- **Response:** Generated image URL, generation_id

### View Gallery
- **Endpoint:** `GET /gallery`
- **Response:** HTML page with all generated images

## Usage Examples

### Web Interface
1. Navigate to `http://localhost:5000`
2. Upload product image or enter product description
3. Select style preferences (studio, lifestyle, 360-view, etc.)
4. Click "Generate"
5. Download or share generated images

### Python API

```python
import requests

# Generate image
response = requests.post('http://localhost:5000/generate', json={
    'prompt': 'Professional studio lighting, white background, luxury watch',
    'style': 'studio',
    'product_category': 'jewelry'
})

image_url = response.json()['image_url']
```

## API Key Management

1. Get OpenAI API key from https://platform.openai.com/api-keys
2. Ensure DALL-E 3 access is enabled
3. Monitor usage at https://platform.openai.com/account/usage
4. Set appropriate rate limits in dashboard

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Invalid API key" | Verify OPENAI_API_KEY in .env is correct |
| "Rate limit exceeded" | Wait 60 seconds, check API usage quota |
| "Image generation failed" | Ensure prompt doesn't violate OpenAI policies |
| "Port already in use" | Change PORT in .env or kill process on port 5000 |

## Scaling & Deployment

### Production Deployment with Gunicorn

```bash
gunicorn --workers 4 --bind 0.0.0.0:5000 app:app
```

### Using AWS S3 Storage

Enable AWS_BUCKET in .env. Images will auto-upload to S3 for CDN distribution.

### Rate Limiting

Configure in app.py:
- Default: 10 requests/minute per user
- Enterprise: custom limits available

## License & Support

License: Commercial (one-time $297)
Included: Commercial use, unlimited generations, priority support for 1 year

For updates, support, or licensing questions:
Email: support@dreamrenderai.com
Docs: https://docs.dreamrenderai.com

## Version History

- v1.0.0 - Initial release (Feb 2025)
