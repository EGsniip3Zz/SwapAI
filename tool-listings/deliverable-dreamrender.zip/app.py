"""
DreamRender AI - Product Photo Generator
Main Flask application with image generation and gallery endpoints.
"""

import os
import json
import uuid
import logging
from datetime import datetime
from functools import wraps
from pathlib import Path

import openai
from flask import Flask, request, jsonify, render_template, send_from_directory
from PIL import Image
import boto3
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = os.getenv('UPLOAD_FOLDER', './uploads')
app.config['GALLERY_FOLDER'] = os.getenv('GALLERY_FOLDER', './gallery')
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB max file size

# Create necessary directories
Path(app.config['UPLOAD_FOLDER']).mkdir(parents=True, exist_ok=True)
Path(app.config['GALLERY_FOLDER']).mkdir(parents=True, exist_ok=True)
Path('./metadata').mkdir(parents=True, exist_ok=True)

# Configure OpenAI
openai.api_key = os.getenv('OPENAI_API_KEY')

# Configure AWS S3 (optional)
AWS_BUCKET = os.getenv('AWS_BUCKET')
AWS_REGION = os.getenv('AWS_REGION', 'us-east-1')
if AWS_BUCKET:
    s3_client = boto3.client('s3', region_name=AWS_REGION)
else:
    s3_client = None

# Rate limiting decorator
def rate_limit(max_calls=10, time_window=60):
    """Simple rate limiter using in-memory storage"""
    def decorator(f):
        calls = {}
        
        @wraps(f)
        def decorated_function(*args, **kwargs):
            user_id = request.remote_addr
            now = datetime.now().timestamp()
            
            if user_id not in calls:
                calls[user_id] = []
            
            # Remove old calls outside time window
            calls[user_id] = [call_time for call_time in calls[user_id] 
                             if now - call_time < time_window]
            
            if len(calls[user_id]) >= max_calls:
                return jsonify({'error': 'Rate limit exceeded'}), 429
            
            calls[user_id].append(now)
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator


def remove_background_placeholder(image_path):
    """
    Placeholder for background removal.
    In production, integrate with rembg or similar library.
    """
    try:
        img = Image.open(image_path)
        # Simple processing - convert to RGB if needed
        if img.mode in ('RGBA', 'LA', 'P'):
            # Create white background
            background = Image.new('RGB', img.size, (255, 255, 255))
            if img.mode == 'P':
                img = img.convert('RGBA')
            background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
            return background
        return img
    except Exception as e:
        logger.error(f"Error processing background: {e}")
        return None


def upload_to_s3(file_path, s3_key):
    """Upload file to S3 bucket"""
    if not s3_client:
        return None
    
    try:
        s3_client.upload_file(
            file_path,
            AWS_BUCKET,
            s3_key,
            ExtraArgs={'ContentType': 'image/png', 'ACL': 'public-read'}
        )
        return f"https://{AWS_BUCKET}.s3.{AWS_REGION}.amazonaws.com/{s3_key}"
    except Exception as e:
        logger.error(f"S3 upload error: {e}")
        return None


@app.route('/')
def index():
    """Serve the main upload interface"""
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
@rate_limit(max_calls=20, time_window=60)
def upload_image():
    """
    Handle product image upload
    
    Returns:
        JSON with image_id, file_path, dimensions
    """
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    product_name = request.form.get('product_name', 'product')
    
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    # Validate file type
    allowed_extensions = {'png', 'jpg', 'jpeg', 'webp'}
    if not ('.' in file.filename and file.filename.split('.')[-1].lower() in allowed_extensions):
        return jsonify({'error': 'Invalid file type'}), 400
    
    try:
        # Save uploaded file
        image_id = str(uuid.uuid4())
        filename = f"{image_id}.jpg"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        # Open and process image
        img = Image.open(file.stream)
        img = img.convert('RGB')
        
        # Resize if too large (max 2048px on longest side)
        max_size = 2048
        img.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
        
        img.save(filepath, 'JPEG', quality=95)
        
        # Store metadata
        metadata = {
            'image_id': image_id,
            'product_name': product_name,
            'upload_time': datetime.now().isoformat(),
            'dimensions': img.size,
            'file_path': filepath
        }
        
        metadata_path = f'./metadata/{image_id}.json'
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f)
        
        logger.info(f"Image uploaded: {image_id}")
        
        return jsonify({
            'success': True,
            'image_id': image_id,
            'file_path': f'/images/{filename}',
            'dimensions': img.size,
            'product_name': product_name
        })
    
    except Exception as e:
        logger.error(f"Upload error: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/generate', methods=['POST'])
@rate_limit(max_calls=10, time_window=60)
def generate_image():
    """
    Generate product image using DALL-E 3
    
    Request JSON:
        - prompt: Description of product
        - style: 'studio', 'lifestyle', '360-view', 'flat-lay'
        - product_category: Product type
    
    Returns:
        JSON with image_url, generation_id, timestamp
    """
    try:
        data = request.get_json()
        
        if not data or 'prompt' not in data:
            return jsonify({'error': 'Missing prompt'}), 400
        
        prompt = data.get('prompt', '').strip()
        style = data.get('style', 'studio')
        product_category = data.get('product_category', 'general')
        
        if not prompt or len(prompt) < 10:
            return jsonify({'error': 'Prompt must be at least 10 characters'}), 400
        
        # Enhance prompt with style and quality directives
        enhanced_prompt = f"{prompt}. Style: {style}. Professional product photography, high quality, studio lighting, clean background, 8k resolution."
        
        logger.info(f"Generating image for prompt: {prompt[:50]}...")
        
        # Call DALL-E 3 API
        response = openai.Image.create(
            model="dall-e-3",
            prompt=enhanced_prompt,
            n=1,
            size="1024x1024",
            quality="hd",
            style="vivid"
        )
        
        image_url = response['data'][0]['url']
        generation_id = str(uuid.uuid4())
        
        # Store generation metadata
        gen_metadata = {
            'generation_id': generation_id,
            'prompt': prompt,
            'style': style,
            'category': product_category,
            'image_url': image_url,
            'timestamp': datetime.now().isoformat(),
            'usage': response.get('usage', {})
        }
        
        with open(f'./metadata/{generation_id}.json', 'w') as f:
            json.dump(gen_metadata, f)
        
        logger.info(f"Image generated successfully: {generation_id}")
        
        return jsonify({
            'success': True,
            'image_url': image_url,
            'generation_id': generation_id,
            'timestamp': datetime.now().isoformat(),
            'style': style
        })
    
    except openai.error.AuthenticationError:
        logger.error("OpenAI authentication failed")
        return jsonify({'error': 'Invalid OpenAI API key'}), 401
    except openai.error.RateLimitError:
        logger.warning("OpenAI rate limit exceeded")
        return jsonify({'error': 'API rate limit exceeded. Please try again in a moment.'}), 429
    except Exception as e:
        logger.error(f"Generation error: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/gallery')
def gallery():
    """Serve gallery view of generated images"""
    return render_template('gallery.html')


@app.route('/api/gallery-items')
def get_gallery_items():
    """Get all generated images metadata for gallery display"""
    try:
        items = []
        for metadata_file in Path('./metadata').glob('*.json'):
            with open(metadata_file) as f:
                metadata = json.load(f)
                if 'image_url' in metadata:  # Only include generated images
                    items.append(metadata)
        
        # Sort by timestamp, newest first
        items.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        
        return jsonify(items)
    except Exception as e:
        logger.error(f"Gallery error: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/images/<filename>')
def serve_image(filename):
    """Serve uploaded images"""
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })


@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({'error': 'Endpoint not found'}), 404


@app.errorhandler(500)
def server_error(error):
    """Handle 500 errors"""
    logger.error(f"Server error: {error}")
    return jsonify({'error': 'Internal server error'}), 500


if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('FLASK_ENV') == 'development'
    
    logger.info(f"Starting DreamRender AI on port {port}")
    app.run(host='0.0.0.0', port=port, debug=debug)
